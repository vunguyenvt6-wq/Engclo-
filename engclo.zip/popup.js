(async function () {
  const $ = id => document.getElementById(id);

  async function stats() {
    const items = await VS.getItems();
    $('sTotal').textContent = items.length;
    $('sDue').textContent = items.filter(VS.isDue).length;
    $('sDone').textContent = items.filter(i => ((i.srs && i.srs.box) || 0) >= 5).length;
  }

  document.querySelectorAll('[data-go]').forEach(b => b.addEventListener('click', () => {
    chrome.tabs.create({ url: chrome.runtime.getURL('manage.html#' + b.dataset.go) });
    window.close();
  }));

  async function addCat() {
    const name = $('catName').value.trim();
    if (!name) return;
    const cat = await VS.addCategory(name);
    $('catName').value = '';
    $('msg').textContent = '✓ Đã thêm danh mục “' + cat.name + '”';
    setTimeout(() => { $('msg').textContent = ''; }, 2500);
  }
  $('catAdd').addEventListener('click', addCat);
  $('catName').addEventListener('keydown', e => { if (e.key === 'Enter') addCat(); });

  const s = await VS.getSettings();
  $('enabled').checked = s.enabled !== false;
  $('enabled').addEventListener('change', e => VS.setSettings({ enabled: e.target.checked }));

  await VS.getCategories();
  stats();

  // Kiểm tra & hiển thị thông báo cập nhật
  try {
    const up = await EngcloAnalytics.getUpdateInfo();
    if (up && up.hasUpdate) {
      const notice = $('updateNotice');
      if (notice) {
        $('upVer').textContent = up.latestVersion;
        const link = $('upLink');
        if (up.downloadUrl) link.href = up.downloadUrl;
        notice.style.display = 'flex';
      }
    }
  } catch (e) { /* bỏ qua */ }

  // Telemetry: lượt mở popup
  try {
    chrome.runtime.sendMessage({ type: 'track', event: 'open_popup' });
  } catch (e) { /* bỏ qua */ }
})();
