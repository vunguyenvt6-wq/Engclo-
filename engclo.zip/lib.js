/* Engclo – hàm dùng chung (service worker, content script, các trang của extension) */
(function (g) {
  'use strict';

  const DAY = 86400000;
  const COLORS = ['#2e7d32', '#15803d', '#059669', '#0d9488', '#0284c7', '#ca8a04', '#ea580c', '#e11d48', '#4b5563'];
  const POS_VI = {
    noun: 'danh từ', verb: 'động từ', adjective: 'tính từ', adverb: 'trạng từ',
    pronoun: 'đại từ', preposition: 'giới từ', conjunction: 'liên từ',
    interjection: 'thán từ', exclamation: 'thán từ', determiner: 'từ hạn định',
    article: 'mạo từ', numeral: 'số từ', abbreviation: 'viết tắt',
    'phrasal verb': 'cụm động từ', prefix: 'tiền tố', suffix: 'hậu tố',
    particle: 'tiểu từ', auxiliary: 'trợ động từ', 'modal verb': 'động từ khuyết thiếu',
    idiom: 'thành ngữ', contraction: 'dạng rút gọn', phrase: 'cụm từ'
  };
  const INTERVALS = [0, 1, 3, 7, 14, 30, 60]; // ngày, theo "hộp" Leitner
  const ITEM_PREFIX = 'i_';

  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => (
    { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const escRe = s => String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const norm = s => String(s == null ? '' : s).toLowerCase().replace(/\s+/g, ' ').trim();
  const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
  const cleanWord = s => String(s || '').replace(/^[^A-Za-z0-9]+|[^A-Za-z0-9]+$/g, '');
  const posVi = p => POS_VI[String(p || '').toLowerCase()] || p || '';

  // Bọc <mark> quanh các cụm trong terms (không phân biệt hoa/thường, theo ranh giới từ)
  function markHTML(text, terms) {
    text = String(text == null ? '' : text);
    terms = (terms || []).map(t => String(t || '').trim()).filter(Boolean);
    if (!terms.length) return esc(text);
    terms.sort((a, b) => b.length - a.length);
    let re;
    try {
      re = new RegExp('(?<![A-Za-z0-9])(' + terms.map(escRe).join('|') + ')(?![A-Za-z0-9])', 'gi');
    } catch (e) { return esc(text); }
    return text.split(re).map((part, i) => (i % 2 ? '<mark>' + esc(part) + '</mark>' : esc(part))).join('');
  }

  /* ---------- Settings & Categories ---------- */
  async function getSettings() {
    const r = await chrome.storage.local.get('settings');
    return Object.assign({ targetLang: 'vi', enabled: true, lastCategoryId: null, quizBest: 0 }, r.settings || {});
  }
  async function setSettings(patch) {
    const s = Object.assign(await getSettings(), patch);
    await chrome.storage.local.set({ settings: s });
    return s;
  }
  async function getCategories() {
    const r = await chrome.storage.local.get('categories');
    let c = r.categories;
    if (!Array.isArray(c) || !c.length) {
      c = [{ id: 'default', name: 'Mặc định', color: COLORS[0] }];
      await chrome.storage.local.set({ categories: c });
    }
    return c;
  }
  async function saveCategories(c) { await chrome.storage.local.set({ categories: c }); }
  async function addCategory(name, color) {
    name = String(name || '').trim();
    const cats = await getCategories();
    const ex = cats.find(c => norm(c.name) === norm(name));
    if (ex) return ex;
    const cat = { id: uid(), name, color: color || COLORS[cats.length % COLORS.length] };
    cats.push(cat);
    await saveCategories(cats);
    return cat;
  }

  /* ---------- Items (mỗi mục một khóa i_<id> để ghi không đè nhau) ---------- */
  async function getItems() {
    const all = await chrome.storage.local.get(null);
    return Object.keys(all).filter(k => k.startsWith(ITEM_PREFIX)).map(k => all[k]);
  }
  async function getItem(id) {
    const r = await chrome.storage.local.get(ITEM_PREFIX + id);
    return r[ITEM_PREFIX + id] || null;
  }
  async function putItem(item) { await chrome.storage.local.set({ [ITEM_PREFIX + item.id]: item }); }
  async function putItems(items) {
    for (let i = 0; i < items.length; i += 200) {
      const obj = {};
      items.slice(i, i + 200).forEach(it => { obj[ITEM_PREFIX + it.id] = it; });
      await chrome.storage.local.set(obj);
    }
  }
  async function updateItem(id, patch) {
    const cur = await getItem(id);
    if (!cur) return null;
    const next = typeof patch === 'function' ? (patch(cur) || cur) : Object.assign(cur, patch);
    next.updatedAt = Date.now();
    await putItem(next);
    return next;
  }
  async function deleteItems(ids) {
    for (let i = 0; i < ids.length; i += 200) {
      await chrome.storage.local.remove(ids.slice(i, i + 200).map(x => ITEM_PREFIX + x));
    }
  }
  function newItem(p) {
    const now = Date.now();
    return {
      id: uid(), type: p.type || 'word', text: p.text, meaning: p.meaning || '',
      phonetic: p.phonetic || '', audio: p.audio || '', pos: p.pos || [], meanings: p.meanings || [],
      defs: p.defs || [], examples: p.examples || [], focus: p.focus || [], context: p.context || '',
      note: p.note || '', categoryId: p.categoryId || 'default', source: p.source || null,
      enriched: !!p.enriched, createdAt: now, updatedAt: now,
      srs: { box: 0, due: 0, correct: 0, wrong: 0, last: 0 }
    };
  }
  // Lưu mới hoặc cập nhật nếu cùng loại + cùng nội dung đã tồn tại
  async function saveItem(p) {
    const items = await getItems();
    const key = norm(p.text);
    const ex = items.find(i => i.type === p.type && norm(i.text) === key);
    if (ex) {
      const item = await updateItem(ex.id, cur => {
        if (p.categoryId) cur.categoryId = p.categoryId;
        if (p.context) cur.context = p.context;
        if (p.focus && p.focus.length) cur.focus = p.focus;
        if (p.meaning && !cur.meaning) cur.meaning = p.meaning;
        if (p.source) cur.source = p.source;
        return cur;
      });
      return { item, updated: true };
    }
    const item = newItem(p);
    await putItem(item);
    return { item, updated: false };
  }

  /* ---------- Lặp lại ngắt quãng (Leitner) ---------- */
  function applyGrade(item, grade) { // 'again' | 'hard' | 'good'
    const s = item.srs || (item.srs = { box: 0, due: 0, correct: 0, wrong: 0, last: 0 });
    const now = Date.now();
    s.last = now;
    if (grade === 'again') { s.box = 0; s.wrong++; s.due = now + 5 * 60 * 1000; }
    else if (grade === 'hard') { s.box = Math.max(1, s.box); s.correct++; s.due = now + DAY; }
    else { s.box = Math.min(s.box + 1, INTERVALS.length - 1); s.correct++; s.due = now + INTERVALS[s.box] * DAY; }
    return item;
  }
  const isDue = i => ((i.srs && i.srs.due) || 0) <= Date.now();

  /* ---------- Phát âm ---------- */
  function tts(text) {
    try {
      const u = new SpeechSynthesisUtterance(text);
      u.lang = 'en-US'; u.rate = 0.95;
      speechSynthesis.cancel(); speechSynthesis.speak(u);
    } catch (e) { /* bỏ qua */ }
  }
  function speak(text, audioUrl) {
    if (audioUrl && /^https?:/i.test(audioUrl)) {
      try { const a = new Audio(audioUrl); a.play().catch(() => tts(text)); return; } catch (e) { /* rơi xuống TTS */ }
    }
    tts(text);
  }

  g.VS = {
    DAY, COLORS, POS_VI, INTERVALS, ITEM_PREFIX,
    esc, escRe, norm, uid, cleanWord, posVi, markHTML,
    getSettings, setSettings, getCategories, saveCategories, addCategory,
    getItems, getItem, putItem, putItems, updateItem, deleteItems, newItem, saveItem,
    applyGrade, isDue, speak
  };
})(globalThis);
