/* Engclo – Module Analytics GA4 & Auto Check Update
 * Hoạt động 100% không cần server trung gian.
 */
(function (g) {
  'use strict';

  // Cấu hình GA4 mặc định (nhúng sẵn để mọi máy cài từ zip phân phối tự gửi thống kê)
  const DEFAULT_CONFIG = {
    measurementId: 'G-MQHGN6XPRX',
    apiSecret: '9bSD17VZQvyBoQM3DQ57_A',
    updateCheckUrl: 'https://raw.githubusercontent.com/vunguyenvt6-wq/Engclo-/main/version.json'
  };

  async function getConfig() {
    try {
      const r = await chrome.storage.local.get('engclo_config');
      return Object.assign({}, DEFAULT_CONFIG, r.engclo_config || {});
    } catch (e) {
      return Object.assign({}, DEFAULT_CONFIG);
    }
  }

  async function setConfig(patch) {
    const cur = await getConfig();
    const next = Object.assign(cur, patch);
    await chrome.storage.local.set({ engclo_config: next });
    return next;
  }

  async function getClientId() {
    try {
      const r = await chrome.storage.local.get('engclo_client_id');
      if (r.engclo_client_id) return r.engclo_client_id;
      const newId = 'c_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 10);
      await chrome.storage.local.set({ engclo_client_id: newId });
      return newId;
    } catch (e) {
      return 'anonymous_client';
    }
  }

  function getSessionId() {
    return Math.floor(Date.now() / (30 * 60 * 1000)).toString();
  }

  /* Gửi event lên Google Analytics 4 */
  async function track(eventName, params) {
    try {
      const cfg = await getConfig();
      if (!cfg.measurementId || !cfg.apiSecret) return false;
      const clientId = await getClientId();
      const payload = {
        client_id: clientId,
        events: [
          {
            name: eventName,
            params: Object.assign(
              {
                session_id: getSessionId(),
                engagement_time_msec: 100,
                app_version: (chrome.runtime && chrome.runtime.getManifest) ? chrome.runtime.getManifest().version : '1.0.0'
              },
              params || {}
            )
          }
        ]
      };
      const url = `https://www.google-analytics.com/mp/collect?measurement_id=${encodeURIComponent(cfg.measurementId)}&api_secret=${encodeURIComponent(cfg.apiSecret)}`;
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      return res.ok;
    } catch (e) {
      return false;
    }
  }

  /* So sánh 2 chuỗi version ngữ nghĩa (ví dụ: '1.0.1' > '1.0.0') */
  function compareVersions(v1, v2) {
    if (!v1 || !v2) return 0;
    const p1 = String(v1).replace(/^v/i, '').split('.').map(x => parseInt(x, 10) || 0);
    const p2 = String(v2).replace(/^v/i, '').split('.').map(x => parseInt(x, 10) || 0);
    for (let i = 0; i < Math.max(p1.length, p2.length); i++) {
      const n1 = p1[i] || 0, n2 = p2[i] || 0;
      if (n1 > n2) return 1;
      if (n1 < n2) return -1;
    }
    return 0;
  }

  /* Tự động kiểm tra bản cập nhật mới */
  async function checkForUpdate() {
    try {
      const cfg = await getConfig();
      if (!cfg.updateCheckUrl) return null;
      const ctrl = new AbortController();
      const t = setTimeout(() => ctrl.abort(), 6000);
      const resp = await fetch(cfg.updateCheckUrl + (cfg.updateCheckUrl.includes('?') ? '&' : '?') + 't=' + Date.now(), {
        signal: ctrl.signal,
        cache: 'no-store'
      });
      clearTimeout(t);
      if (!resp.ok) return null;
      const data = await resp.json();
      const currentVer = (chrome.runtime && chrome.runtime.getManifest) ? chrome.runtime.getManifest().version : '1.0.0';
      const latestVer = data.version;
      const isNewer = compareVersions(latestVer, currentVer) > 0;
      const updateInfo = {
        hasUpdate: isNewer,
        currentVersion: currentVer,
        latestVersion: latestVer || currentVer,
        downloadUrl: data.download_url || '',
        changelog: data.changelog || '',
        checkedAt: Date.now()
      };
      await chrome.storage.local.set({ engclo_update_info: updateInfo });
      return updateInfo;
    } catch (e) {
      return null;
    }
  }

  async function getUpdateInfo() {
    try {
      const r = await chrome.storage.local.get('engclo_update_info');
      return r.engclo_update_info || null;
    } catch (e) {
      return null;
    }
  }

  g.EngcloAnalytics = {
    DEFAULT_CONFIG,
    getConfig,
    setConfig,
    getClientId,
    track,
    compareVersions,
    checkForUpdate,
    getUpdateInfo
  };
})(globalThis);
