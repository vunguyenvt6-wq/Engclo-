/* Engclo – trang quản lý: kho từ vựng, flashcard, quiz, danh mục, dữ liệu */
(() => {
  'use strict';
  const { esc, norm, markHTML } = VS;
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];

  const st = {
    view: 'library', items: [], cats: [], settings: {},
    f: { q: '', cat: 'all', type: 'all', level: 'all', sort: 'new', limit: 60, sel: new Set() },
    flash: null, quiz: null, enrichRun: null, modalId: null
  };
  const VIEWS = ['library', 'flash', 'quiz', 'cats', 'data'];
  const TYPE_LABEL = { word: 'Từ', phrase: 'Cụm từ', sentence: 'Câu' };
  const LEVELS = { all: 'Mọi mức độ', new: 'Chưa nhớ', learning: 'Đang học', good: 'Khá', mastered: 'Đã thuộc' };

  /* ---------- tiện ích ---------- */
  const levelKey = i => { const b = (i.srs && i.srs.box) || 0; return b === 0 ? 'new' : b <= 2 ? 'learning' : b <= 4 ? 'good' : 'mastered'; };
  const shuffle = a => { for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };
  const pick = a => a[Math.floor(Math.random() * a.length)];
  const unique = a => { const s = new Set(); return a.filter(x => { const k = norm(x); if (s.has(k)) return false; s.add(k); return true; }); };
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const catOf = id => st.cats.find(c => c.id === id) || st.cats[0] || { id: 'default', name: 'Mặc định', color: '#2e7d32' };
  const fmtDate = ts => new Date(ts).toLocaleDateString('vi-VN');
  const catOptions = sel => st.cats.map(c => `<option value="${esc(c.id)}"${c.id === sel ? ' selected' : ''}>${esc(c.name)}</option>`).join('');
  const sendMsg = msg => new Promise(res => {
    try { chrome.runtime.sendMessage(msg, r => { void chrome.runtime.lastError; res(r); }); } catch (e) { res(null); }
  });
  let toastT;
  function toast(m) {
    const t = $('#toast'); t.textContent = m; t.classList.add('on');
    clearTimeout(toastT); toastT = setTimeout(() => t.classList.remove('on'), 2600);
  }
  const modalOpen = () => $('#modal').children.length > 0;
  function openModal(html) { $('#modal').innerHTML = '<div class="mback"><div class="mbox">' + html + '</div></div>'; }
  function closeModal() { $('#modal').innerHTML = ''; st.modalId = null; }

  /* ---------- tải dữ liệu ---------- */
  async function load() {
    const [items, cats, settings] = await Promise.all([VS.getItems(), VS.getCategories(), VS.getSettings()]);
    st.items = items; st.cats = cats; st.settings = settings;
    for (const id of [...st.f.sel]) if (!items.some(i => i.id === id)) st.f.sel.delete(id);
  }
  function renderStats() {
    const words = st.items.filter(i => i.type !== 'sentence').length;
    $('#stats').innerHTML = `<span><b>${words}</b> từ/cụm</span><span><b>${st.items.length - words}</b> câu</span><span><b>${st.items.filter(VS.isDue).length}</b> cần ôn</span>`;
  }
  function go(view) {
    stopQuizTimer();
    st.view = view;
    try { history.replaceState(null, '', '#' + view); } catch (e) { /* bỏ qua */ }
    $$('#nav button').forEach(b => b.classList.toggle('active', b.dataset.view === view));
    render();
    window.scrollTo(0, 0);
  }
  function render() {
    ({ library: renderLibrary, flash: renderFlash, quiz: renderQuiz, cats: renderCats, data: renderData })[st.view]();
  }

  /* =====================================================
   *  KHO TỪ VỰNG
   * ===================================================== */
  function emptyHTML() {
    return `<div class="empty"><div class="big">📭</div><h2>Chưa có từ vựng nào</h2>
      <div class="guide">1. Mở một trang web tiếng Anh bất kỳ<br>2. <b>Bôi đen</b> một từ hoặc một câu<br>3. Bấm icon <b>＋</b> màu tím hiện ra cạnh đoạn chọn<br>4. Chọn danh mục (hoặc tạo nhanh danh mục mới) rồi bấm <b>Lưu</b></div>
      <div style="margin-top:20px"><button class="btn" data-act="add">＋ Hoặc thêm thủ công</button></div></div>`;
  }
  function filtered() {
    const f = st.f;
    let a = st.items.slice();
    if (f.cat !== 'all') a = a.filter(i => i.categoryId === f.cat);
    if (f.type !== 'all') a = a.filter(i => i.type === f.type);
    if (f.level !== 'all') a = a.filter(i => levelKey(i) === f.level);
    if (f.q) {
      const q = norm(f.q);
      a = a.filter(i => [i.text, i.meaning, i.note, i.context].some(x => norm(x).includes(q)));
    }
    const sorters = {
      new: (x, y) => y.createdAt - x.createdAt,
      old: (x, y) => x.createdAt - y.createdAt,
      az: (x, y) => x.text.localeCompare(y.text),
      due: (x, y) => ((x.srs && x.srs.due) || 0) - ((y.srs && y.srs.due) || 0)
    };
    return a.sort(sorters[f.sort] || sorters.new);
  }

  function renderLibrary() {
    const f = st.f;
    if (!st.items.length) { $('#view').innerHTML = emptyHTML(); return; }
    const counts = {};
    st.items.forEach(i => { counts[i.categoryId] = (counts[i.categoryId] || 0) + 1; });
    $('#view').innerHTML = `
      <div class="row sp" style="margin-bottom:14px"><h2 style="margin:0">Kho từ vựng</h2><button class="btn" data-act="add">＋ Thêm thủ công</button></div>
      <div class="catchips">
        <button class="cchip ${f.cat === 'all' ? 'on' : ''}" data-act="filter-cat" data-cat="all">Tất cả <small>${st.items.length}</small></button>
        ${st.cats.map(c => `<button class="cchip ${f.cat === c.id ? 'on' : ''}" data-act="filter-cat" data-cat="${esc(c.id)}"><span class="dot" style="background:${esc(c.color)}"></span>${esc(c.name)} <small>${counts[c.id] || 0}</small></button>`).join('')}
      </div>
      <div class="toolbar">
        <input type="search" id="fq" placeholder="Tìm từ, nghĩa, ghi chú…" value="${esc(f.q)}">
        <select id="ftype"><option value="all">Mọi loại</option><option value="word">Từ</option><option value="phrase">Cụm từ</option><option value="sentence">Câu</option></select>
        <select id="flevel">${Object.keys(LEVELS).map(k => `<option value="${k}">${LEVELS[k]}</option>`).join('')}</select>
        <select id="fsort"><option value="new">Mới nhất</option><option value="old">Cũ nhất</option><option value="az">A → Z</option><option value="due">Sắp đến hạn ôn</option></select>
      </div>
      <div id="list"></div>`;
    $('#ftype').value = f.type; $('#flevel').value = f.level; $('#fsort').value = f.sort;
    renderList();
  }

  function renderList() {
    const box = $('#list');
    if (!box) return;
    const all = filtered(), sel = st.f.sel;
    const shown = all.slice(0, st.f.limit);
    const bulk = sel.size ? `<div class="bulk"><b>Đã chọn ${sel.size}</b>
      <select id="bulkCat">${catOptions('')}</select>
      <button class="ghost sm" data-act="bulk-move">Chuyển danh mục</button>
      <button class="ghost sm danger" data-act="bulk-del">Xóa</button>
      <button class="ghost sm" data-act="bulk-clear">Bỏ chọn</button></div>` : '';
    const allChecked = all.length && all.every(i => sel.has(i.id));
    box.innerHTML = bulk +
      `<div class="row sp muted" style="margin-bottom:8px"><span>${all.length} kết quả</span>
        <label class="chk"><input type="checkbox" data-act="sel-all" ${allChecked ? 'checked' : ''}> Chọn tất cả</label></div>` +
      (shown.map(cardHTML).join('') || '<div class="empty">Không có mục nào khớp bộ lọc.</div>') +
      (all.length > shown.length ? `<div style="text-align:center"><button class="ghost" data-act="more">Hiện thêm (${all.length - shown.length})</button></div>` : '');
  }

  function detailHTML(i) {
    let h = '';
    (i.meanings || []).forEach(m => {
      h += `<div class="mrow"><span class="tag">${esc(m.posVi || m.pos)}</span>${esc((m.vi || []).join(', '))}${m.def ? `<div class="def">${esc(m.def)}</div>` : ''}</div>`;
    });
    (i.examples || []).forEach(e => {
      h += `<div class="exrow"><div>${markHTML(e.en, [i.text])}</div>${e.vi ? `<div class="vi">${esc(e.vi)}</div>` : ''}</div>`;
    });
    if (i.context && i.type !== 'sentence') h += `<div class="ctxrow"><span class="lbl">Ngữ cảnh</span>${markHTML(i.context, [i.text])}</div>`;
    if (i.note) h += `<div class="noterow"><span class="lbl">Ghi chú</span>${esc(i.note)}</div>`;
    return h;
  }

  function cardHTML(i) {
    const c = catOf(i.categoryId), isS = i.type === 'sentence';
    const head = isS
      ? `<div class="sent">${markHTML(i.text, i.focus)} <button class="ib" data-act="speak" title="Đọc cả câu">🔊</button></div>`
      : `<div class="wline"><span class="w">${esc(i.text)}</span>${i.phonetic ? `<span class="ph">${esc(i.phonetic)}</span>` : ''}
          <button class="ib" data-act="speak" title="Phát âm">🔊</button>
          ${(i.pos || []).map(p => `<span class="tag">${esc(p)}</span>`).join('')}${i.type === 'phrase' ? '<span class="tag t2">cụm từ</span>' : ''}</div>`;
    const meaning = i.meaning ? esc(i.meaning) : '<span class="muted">Chưa có nghĩa – bấm ↻ để dịch tự động</span>';
    const detail = detailHTML(i);
    const lvl = Math.min((i.srs && i.srs.box) || 0, 5);
    const src = i.source && /^https?:/i.test(i.source.url || '')
      ? `<a href="${esc(i.source.url)}" target="_blank" rel="noopener">${esc((i.source.title || 'Nguồn').slice(0, 40))}</a>` : '';
    return `<div class="card" data-id="${esc(i.id)}">
      <div class="card-top">
        <input type="checkbox" data-act="sel" ${st.f.sel.has(i.id) ? 'checked' : ''}>
        <div class="card-main">${head}<div class="mean">${meaning}</div></div>
        <span class="catbadge"><span class="dot" style="background:${esc(c.color)}"></span>${esc(c.name)}</span>
      </div>
      ${detail ? `<details class="more"><summary>Chi tiết</summary>${detail}</details>` : ''}
      <div class="card-foot">
        <span><span class="lvl" title="Mức độ nhớ">${'●'.repeat(lvl)}${'○'.repeat(5 - lvl)}</span> · ${fmtDate(i.createdAt)} ${src ? '· ' + src : ''}</span>
        <span class="acts">
          ${(!isS || !i.meaning) ? '<button class="ghost sm" data-act="enrich" title="Dịch/tra từ điển lại">↻</button>' : ''}
          <button class="ghost sm" data-act="edit">✏️ Sửa</button>
          <button class="ghost sm danger" data-act="del">🗑️</button>
        </span>
      </div>
    </div>`;
  }

  /* ---------- Sửa / thêm ---------- */
  function editModal(item) {
    const it = item || {
      type: 'word', text: '', meaning: '', note: '', context: '', focus: [], examples: [],
      categoryId: st.f.cat !== 'all' ? st.f.cat : (st.settings.lastCategoryId || st.cats[0].id)
    };
    st.modalId = item ? item.id : null;
    const exText = (it.examples || []).map(x => x.en + (x.vi ? ' | ' + x.vi : '')).join('\n');
    openModal(`
      <h3>${item ? 'Chỉnh sửa' : 'Thêm mới'}</h3>
      <label class="f">Loại</label>
      <select id="m-type"><option value="word">Từ</option><option value="phrase">Cụm từ</option><option value="sentence">Câu</option></select>
      <label class="f">Từ / cụm từ / câu</label>
      <textarea id="m-text" rows="2">${esc(it.text)}</textarea>
      <label class="f">Nghĩa / bản dịch ${item ? '' : '(để trống = tự động dịch)'}</label>
      <textarea id="m-meaning" rows="2">${esc(it.meaning)}</textarea>
      <div id="m-focus-wrap"><label class="f">Từ trọng tâm được highlight (cách nhau bằng dấu phẩy)</label>
        <input type="text" id="m-focus" value="${esc((it.focus || []).join(', '))}"></div>
      <div id="m-ctx-wrap"><label class="f">Câu ngữ cảnh (từ sẽ được highlight trong câu)</label>
        <textarea id="m-context" rows="2">${esc(it.context)}</textarea>
        <label class="f">Ví dụ (mỗi dòng: English | Tiếng Việt)</label>
        <textarea id="m-ex" rows="3">${esc(exText)}</textarea></div>
      <label class="f">Ghi chú</label>
      <input type="text" id="m-note" value="${esc(it.note)}">
      <label class="f">Danh mục</label>
      <select id="m-cat">${catOptions(it.categoryId)}</select>
      <div class="row" style="justify-content:flex-end;margin-top:18px">
        <button class="ghost" data-act="m-cancel">Hủy</button><button class="btn" data-act="m-save">Lưu</button>
      </div>`);
    $('#m-type').value = it.type;
    const sync = () => {
      const s = $('#m-type').value === 'sentence';
      $('#m-focus-wrap').hidden = !s; $('#m-ctx-wrap').hidden = s;
    };
    $('#m-type').addEventListener('change', sync);
    sync();
    $('#m-text').focus();
  }

  async function modalSave() {
    const type = $('#m-type').value;
    const text = $('#m-text').value.replace(/\s+/g, ' ').trim();
    if (!text) { toast('Hãy nhập nội dung'); return; }
    const meaning = $('#m-meaning').value.trim();
    const focus = $('#m-focus').value.split(',').map(s => s.trim()).filter(Boolean);
    const context = $('#m-context').value.trim();
    const note = $('#m-note').value.trim();
    const categoryId = $('#m-cat').value;
    const examples = $('#m-ex').value.split('\n').map(l => l.trim()).filter(Boolean).map(l => {
      const [en, ...rest] = l.split('|');
      return { en: en.trim(), vi: rest.join('|').trim() };
    });
    const isS = type === 'sentence';
    if (st.modalId) {
      await VS.updateItem(st.modalId, cur => Object.assign(cur, {
        type, text, meaning, note, categoryId, examples: isS ? [] : examples,
        context: isS ? '' : context, focus: isS ? focus : []
      }));
      toast('Đã lưu thay đổi');
    } else {
      const r = await VS.saveItem({ type, text, meaning, note, categoryId, focus: isS ? focus : [], context: isS ? '' : context, examples: isS ? [] : examples });
      toast(r.updated ? 'Mục này đã có – đã cập nhật' : 'Đã thêm');
      if (!r.item.enriched || !r.item.meaning) sendMsg({ type: 'enrich', id: r.item.id });
    }
    closeModal();
    await load(); renderStats(); render();
  }

  /* =====================================================
   *  FLASHCARD
   * ===================================================== */
  function renderFlash() {
    if (!st.flash) return renderFlashConfig();
    const fl = st.flash;
    if (fl.i >= fl.deck.length) return renderFlashDone();
    const it = fl.deck[fl.i];
    const frontEn = it.type === 'sentence'
      ? `<div class="bigs">${markHTML(it.text, it.focus)}</div>`
      : `<div class="bigw">${esc(it.text)}</div>${it.phonetic ? `<div class="ph">${esc(it.phonetic)}</div>` : ''}`;
    const frontVi = `<div class="${it.type === 'sentence' ? 'bigs' : 'bigw'}">${esc(it.meaning || '(chưa có nghĩa)')}</div>${(it.pos || []).length ? `<div style="margin-top:8px">${it.pos.map(p => `<span class="tag">${esc(p)}</span>`).join('')}</div>` : ''}`;
    const back = `${it.type === 'sentence' ? `<div class="bigs" style="font-size:18px">${markHTML(it.text, it.focus)}</div>` : `<div class="wline"><span class="w">${esc(it.text)}</span><span class="ph">${esc(it.phonetic || '')}</span></div>`}
      <div class="mean">${esc(it.meaning || '')}</div>${detailHTML(it)}`;
    $('#view').innerHTML = `<div class="fc-wrap">
      <div class="row sp"><b>Thẻ ${fl.i + 1}/${fl.deck.length}</b>
        <span class="row"><button class="ib" data-act="f-speak" title="Phát âm">🔊</button><button class="ghost sm" data-act="f-exit">Thoát</button></span></div>
      <div class="progress"><div style="width:${fl.i / fl.deck.length * 100}%"></div></div>
      <div class="flip ${fl.flipped ? 'on' : ''}" data-act="f-flip"><div class="flip-in" style="min-height:340px">
        <div class="face">${fl.dir === 'en' ? frontEn : frontVi}<div class="hintx">Bấm vào thẻ hoặc nhấn <b>Space</b> để lật</div></div>
        <div class="face back">${back}</div>
      </div></div>
      <div class="grade" ${fl.flipped ? '' : 'hidden'}>
        <button class="btn bad" data-act="f-grade" data-g="again">Chưa nhớ <span class="kbd">1</span></button>
        <button class="btn warn" data-act="f-grade" data-g="hard">Hơi khó <span class="kbd">2</span></button>
        <button class="btn ok" data-act="f-grade" data-g="good">Đã nhớ <span class="kbd">3</span></button>
      </div></div>`;
  }
  function renderFlashConfig() {
    const due = st.items.filter(VS.isDue).length;
    $('#view').innerHTML = `<h2>Ôn tập flashcard</h2>
      <div class="panel"><div class="cfg-grid">
        <div><label class="f">Danh mục</label><select id="fcCat"><option value="all">Tất cả</option>${catOptions('')}</select></div>
        <div><label class="f">Phạm vi</label><select id="fcScope"><option value="due">Đến hạn ôn (${due})</option><option value="weak">Chưa thuộc</option><option value="all">Tất cả</option></select></div>
        <div><label class="f">Số thẻ</label><select id="fcCount"><option value="10">10</option><option value="20" selected>20</option><option value="50">50</option><option value="9999">Tất cả</option></select></div>
        <div><label class="f">Mặt trước</label><select id="fcDir"><option value="en">Tiếng Anh → đoán nghĩa</option><option value="vi">Nghĩa → đoán từ</option></select></div>
      </div><div style="margin-top:18px"><button class="btn" data-act="f-start">🧠 Bắt đầu ôn</button></div></div>
      <p class="muted">Thẻ bạn “Đã nhớ” sẽ được hẹn ôn lại sau 1 → 3 → 7 → 14 → 30 ngày (lặp lại ngắt quãng). Phím tắt: Space lật thẻ, 1/2/3 chấm điểm.</p>`;
  }
  function startFlash(deck, dir) {
    if (!deck.length) { toast('Không có thẻ nào phù hợp. Thử chọn phạm vi “Tất cả”.'); return; }
    st.flash = { deck, i: 0, flipped: false, dir, stats: { again: 0, hard: 0, good: 0 }, again: [] };
    renderFlash();
  }
  function flashFromConfig() {
    const cat = $('#fcCat').value, scope = $('#fcScope').value, n = +$('#fcCount').value, dir = $('#fcDir').value;
    let a = st.items.filter(i => cat === 'all' || i.categoryId === cat);
    if (scope === 'due') a = a.filter(VS.isDue);
    else if (scope === 'weak') a = a.filter(i => ((i.srs && i.srs.box) || 0) <= 2);
    startFlash(shuffle(a).slice(0, n), dir);
  }
  function flashFlip() {
    const fl = st.flash;
    if (!fl || fl.flipped) return;
    fl.flipped = true;
    const f = $('.flip'); if (f) f.classList.add('on');
    const g = $('.grade'); if (g) g.hidden = false;
  }
  async function flashGrade(g) {
    const fl = st.flash;
    if (!fl || !fl.flipped) return;
    const it = fl.deck[fl.i];
    await VS.updateItem(it.id, cur => VS.applyGrade(cur, g));
    fl.stats[g]++;
    if (g === 'again') fl.again.push(it);
    fl.i++; fl.flipped = false;
    renderFlash();
  }
  function renderFlashDone() {
    const fl = st.flash, s = fl.stats;
    $('#view').innerHTML = `<div class="fc-wrap"><div class="panel" style="text-align:center">
      <div style="font-size:56px">🎉</div><h2>Hoàn thành ${fl.deck.length} thẻ!</h2>
      <p>✅ Đã nhớ <b>${s.good}</b> · 😐 Hơi khó <b>${s.hard}</b> · ❌ Chưa nhớ <b>${s.again}</b></p>
      <div class="row" style="justify-content:center">
        ${fl.again.length ? `<button class="btn" data-act="f-retry">Ôn lại ${fl.again.length} thẻ chưa nhớ</button>` : ''}
        <button class="ghost" data-act="f-exit">Về cấu hình</button></div></div></div>`;
    load().then(renderStats);
  }

  /* =====================================================
   *  QUIZ GAME
   * ===================================================== */
  const normAns = s => String(s == null ? '' : s).toLowerCase().replace(/[’‘]/g, "'").replace(/[^\p{L}\p{N}' -]/gu, '').replace(/\s+/g, ' ').trim();
  const shortMeaning = i => String(i.meaning || '').replace(/\s+/g, ' ').trim().slice(0, 90);

  function renderQuiz() {
    const qz = st.quiz;
    if (!qz) return renderQuizConfig();
    if (qz.done) return renderQuizResult();
    renderQuizQuestion();
  }
  function renderQuizConfig() {
    $('#view').innerHTML = `<h2>Quiz game</h2>
      <div class="panel"><div class="cfg-grid">
        <div><label class="f">Danh mục</label><select id="qzCat"><option value="all">Tất cả</option>${catOptions('')}</select></div>
        <div><label class="f">Số câu hỏi</label><select id="qzCount"><option value="5">5</option><option value="10" selected>10</option><option value="20">20</option><option value="9999">Tất cả</option></select></div>
        <div><label class="f">Thời gian mỗi câu</label><select id="qzTime"><option value="0">Không giới hạn</option><option value="15">15 giây</option><option value="30">30 giây</option></select></div>
      </div>
      <label class="f">Dạng câu hỏi</label>
      <div><label class="chk"><input type="checkbox" class="qk" value="mc-meaning" checked> Chọn nghĩa đúng</label>
        <label class="chk"><input type="checkbox" class="qk" value="mc-word" checked> Chọn từ đúng</label>
        <label class="chk"><input type="checkbox" class="qk" value="type" checked> Gõ từ tiếng Anh</label>
        <label class="chk"><input type="checkbox" class="qk" value="cloze" checked> Điền chỗ trống trong câu</label></div>
      <div style="margin-top:18px"><button class="btn" data-act="q-start">🎮 Bắt đầu chơi</button></div></div>
      <p class="muted">Điểm cao nhất: <b>${st.settings.quizBest || 0}</b> · Trả lời đúng liên tiếp để nhận điểm thưởng 🔥. Phím tắt: 1–4 chọn đáp án, Enter để tiếp tục.</p>`;
  }

  function clozeInfo(i) {
    let base, targets;
    if (i.type === 'sentence') { base = i.text; targets = i.focus || []; }
    else if (i.context) { base = i.context; targets = [i.text]; }
    else return null;
    for (const t of shuffle(targets.slice())) {
      if (!t) continue;
      const m = new RegExp('(?<![A-Za-z0-9])' + VS.escRe(t) + '(?![A-Za-z0-9])', 'i').exec(base);
      if (m) return { base, target: m[0], index: m.index };
    }
    return null;
  }

  function makeQuestion(item, pool, kinds) {
    const words = pool.filter(p => p.type !== 'sentence' && p.meaning);
    const sm = shortMeaning(item);
    const otherMeanings = unique(pool.filter(p => p.id !== item.id && p.meaning && norm(shortMeaning(p)) !== norm(sm)).map(shortMeaning));
    const otherWords = unique(words.filter(p => p.id !== item.id && norm(p.text) !== norm(item.text)).map(p => p.text));
    const cz = kinds.includes('cloze') ? clozeInfo(item) : null;
    const elig = [];
    if (kinds.includes('mc-meaning') && item.meaning && otherMeanings.length >= 1) elig.push('mc-meaning');
    if (kinds.includes('mc-word') && item.type !== 'sentence' && item.meaning && otherWords.length >= 1) elig.push('mc-word');
    if (kinds.includes('type') && item.type !== 'sentence' && item.meaning) elig.push('type');
    if (cz) elig.push('cloze');
    if (!elig.length) return null;
    const kind = pick(elig);
    const q = { item, kind, small: false, sub: '', options: null, answer: '' };
    if (kind === 'mc-meaning') {
      q.ask = item.type === 'sentence' ? 'Nghĩa của câu này là gì?' : 'Nghĩa của từ này là gì?';
      q.mainHTML = item.type === 'sentence' ? markHTML(item.text, item.focus) : esc(item.text);
      q.small = item.type === 'sentence';
      q.sub = item.phonetic ? esc(item.phonetic) : '';
      q.answer = sm;
      q.options = shuffle([sm, ...shuffle(otherMeanings.slice()).slice(0, 3)]);
    } else if (kind === 'mc-word') {
      q.ask = 'Từ tiếng Anh nào có nghĩa là:';
      q.mainHTML = esc(sm);
      q.answer = item.text;
      q.options = shuffle([item.text, ...shuffle(otherWords.slice()).slice(0, 3)]);
    } else if (kind === 'type') {
      q.ask = 'Gõ từ tiếng Anh có nghĩa là:';
      q.mainHTML = esc(sm);
      q.sub = esc((item.pos || []).join(', ') + ((item.pos || []).length ? ' · ' : '') + item.text.length + ' ký tự');
      q.answer = item.text;
    } else {
      q.ask = 'Điền từ còn thiếu vào chỗ trống:';
      q.mainHTML = esc(cz.base.slice(0, cz.index)) + '<span class="blank">_____</span>' + esc(cz.base.slice(cz.index + cz.target.length));
      q.small = true;
      q.sub = (item.type === 'sentence' ? 'Nghĩa của câu: ' : 'Nghĩa của từ cần điền: ') + esc(sm);
      q.answer = cz.target;
      const bank = unique(pool.flatMap(p => (p.type === 'sentence' ? (p.focus || []) : [p.text])).filter(w => w && norm(w) !== norm(cz.target)));
      if (bank.length >= 3) q.options = shuffle([cz.target, ...shuffle(bank.slice()).slice(0, 3)]);
    }
    return q;
  }

  function startQuiz(cfg, only) {
    const pool = st.items.filter(i => cfg.cat === 'all' || i.categoryId === cfg.cat);
    const targets = shuffle((only || pool).slice());
    const qs = [];
    for (const it of targets) {
      if (qs.length >= cfg.count) break;
      const q = makeQuestion(it, pool, cfg.kinds);
      if (q) qs.push(q);
    }
    if (!qs.length) { toast('Chưa đủ dữ liệu để tạo câu hỏi — hãy lưu thêm từ có nghĩa hoặc chọn thêm dạng câu hỏi.'); return; }
    st.quiz = { cfg, pool, qs, i: 0, score: 0, streak: 0, correct: 0, wrong: [], answered: false, hint: false, timer: null, left: 0, done: false };
    renderQuizQuestion();
  }

  function renderQuizQuestion() {
    const qz = st.quiz, q = qz.qs[qz.i];
    qz.answered = false; qz.hint = false;
    $('#view').innerHTML = `<div class="q-card">
      <div class="q-top"><span>Câu ${qz.i + 1}/${qz.qs.length}</span><span>⭐ ${qz.score}</span><span>🔥 ${qz.streak}</span><button class="ghost sm" data-act="q-exit">Thoát</button></div>
      <div class="progress"><div style="width:${qz.i / qz.qs.length * 100}%"></div></div>
      ${qz.cfg.time ? '<div class="timer"><div id="tbar" style="width:100%"></div></div>' : ''}
      <div class="q-ask">${q.ask}</div>
      <div class="q-main ${q.small ? 's' : ''}">${q.mainHTML}</div>
      ${q.sub ? `<div class="muted">${q.sub}</div>` : ''}
      ${q.options
        ? `<div class="opts">${q.options.map((o, k) => `<button class="opt" data-act="q-opt" data-k="${k}"><span class="n">${k + 1}</span><span>${esc(o)}</span></button>`).join('')}</div>`
        : `<div class="row" style="margin-top:16px"><input type="text" id="qAns" class="grow" placeholder="Nhập đáp án…" autocomplete="off" autocapitalize="off" spellcheck="false"><button class="btn" data-act="q-check">Kiểm tra</button><button class="ghost" data-act="q-hint">💡 Gợi ý</button></div>`}
      <div id="qfb"></div></div>`;
    startQuizTimer();
    const inp = $('#qAns'); if (inp) inp.focus();
  }
  function startQuizTimer() {
    stopQuizTimer();
    const qz = st.quiz;
    if (!qz || !qz.cfg.time) return;
    qz.left = qz.cfg.time;
    qz.timer = setInterval(() => {
      qz.left--;
      const bar = $('#tbar'); if (bar) bar.style.width = Math.max(0, qz.left / qz.cfg.time * 100) + '%';
      if (qz.left <= 0) answerQuestion(null, -1);
    }, 1000);
  }
  function stopQuizTimer() { if (st.quiz && st.quiz.timer) { clearInterval(st.quiz.timer); st.quiz.timer = null; } }

  function answerQuestion(given, chosen) {
    const qz = st.quiz;
    if (!qz || qz.answered) return;
    qz.answered = true; stopQuizTimer();
    const q = qz.qs[qz.i];
    const ok = given != null && normAns(given) === normAns(q.answer);
    if (ok) {
      qz.streak++; qz.correct++;
      const base = 10 + (Math.min(qz.streak, 6) - 1) * 2;
      qz.score += qz.hint ? Math.ceil(base / 2) : base;
    } else { qz.streak = 0; qz.wrong.push({ q, given }); }
    VS.updateItem(q.item.id, cur => VS.applyGrade(cur, ok ? 'good' : 'again'));

    $$('.opt').forEach((b, k) => {
      b.disabled = true;
      if (normAns(q.options[k]) === normAns(q.answer)) b.classList.add('right');
      else if (k === chosen) b.classList.add('wrong');
    });
    const inp = $('#qAns'); if (inp) inp.disabled = true;
    $$('[data-act="q-check"],[data-act="q-hint"]').forEach(b => { b.disabled = true; });

    const it = q.item, last = qz.i + 1 >= qz.qs.length;
    const ex = (it.examples || [])[0];
    $('#qfb').innerHTML = `<div class="fb ${ok ? 'ok' : 'no'}">
      <b>${ok ? '✓ Chính xác!' : (given == null ? '⏰ Hết giờ!' : '✗ Chưa đúng.')}</b> Đáp án: <b>${esc(q.answer)}</b>
      <div style="margin-top:6px">${it.type === 'sentence' ? markHTML(it.text, it.focus) : `<b>${esc(it.text)}</b> ${esc(it.phonetic || '')}`} — ${esc(it.meaning || '')}</div>
      ${ex ? `<div class="muted" style="margin-top:4px">${markHTML(ex.en, [it.text])}</div>` : ''}
      <div class="row" style="margin-top:12px"><button class="btn" data-act="q-next">${last ? 'Xem kết quả' : 'Câu tiếp theo'} ↵</button><button class="ib" data-act="q-speak" title="Phát âm">🔊</button></div></div>`;
    const nb = $('[data-act="q-next"]'); if (nb) nb.focus();
    const bar = $$('.q-top span'); if (bar[1]) bar[1].textContent = '⭐ ' + qz.score; if (bar[2]) bar[2].textContent = '🔥 ' + qz.streak;
  }
  function nextQuestion() {
    const qz = st.quiz;
    if (!qz || !qz.answered) return;
    qz.i++;
    if (qz.i >= qz.qs.length) {
      qz.done = true;
      if (qz.score > (st.settings.quizBest || 0)) { st.settings.quizBest = qz.score; VS.setSettings({ quizBest: qz.score }); qz.newBest = true; }
      renderQuizResult();
      load().then(renderStats);
    } else renderQuizQuestion();
  }
  function renderQuizResult() {
    const qz = st.quiz, n = qz.qs.length, pct = Math.round(qz.correct / n * 100);
    $('#view').innerHTML = `<div class="q-card">
      <div style="text-align:center"><div style="font-size:48px">${pct >= 80 ? '🏆' : pct >= 50 ? '👍' : '💪'}</div>
      <div class="score-big">${qz.score}</div><div class="muted">điểm${qz.newBest ? ' · 🎉 Kỷ lục mới!' : ''}</div>
      <p>Đúng <b>${qz.correct}/${n}</b> câu (${pct}%)</p></div>
      ${qz.wrong.length ? `<h3 style="margin-top:18px">Các câu cần xem lại</h3>${qz.wrong.map(w => `<div class="wrongrow">
        <div>${w.q.item.type === 'sentence' ? markHTML(w.q.item.text, w.q.item.focus) : `<b>${esc(w.q.item.text)}</b>`} — ${esc(w.q.item.meaning || '')}</div>
        <div class="muted">Đáp án: <b>${esc(w.q.answer)}</b>${w.given != null ? ' · Bạn chọn: ' + esc(w.given) : ' · Hết giờ'}</div></div>`).join('')}` : '<p style="text-align:center">Tuyệt vời, không sai câu nào! 🎯</p>'}
      <div class="row" style="justify-content:center;margin-top:20px">
        <button class="btn" data-act="q-retry">🔁 Chơi lại</button>
        ${qz.wrong.length ? '<button class="ghost" data-act="q-retry-wrong">Ôn lại câu sai</button>' : ''}
        <button class="ghost" data-act="q-exit">Về cấu hình</button></div></div>`;
  }

  /* =====================================================
   *  DANH MỤC
   * ===================================================== */
  function renderCats() {
    const counts = {};
    st.items.forEach(i => { counts[i.categoryId] = (counts[i.categoryId] || 0) + 1; });
    $('#view').innerHTML = `<h2>Danh mục</h2>
      <div class="panel"><div class="row"><input type="text" id="newCatName" class="grow" placeholder="Tên danh mục mới (VD: IELTS, Công việc, Phim…)" maxlength="40"><button class="btn" data-act="cat-add">＋ Thêm danh mục</button></div></div>
      <div class="panel">${st.cats.map(c => `<div class="catrow" data-cid="${esc(c.id)}">
        <input type="color" value="${esc(c.color)}" data-act="cat-color" title="Màu danh mục">
        <input type="text" value="${esc(c.name)}" data-act="cat-name" maxlength="40">
        <span class="muted">${counts[c.id] || 0} mục</span>
        <button class="ghost sm danger" data-act="cat-del">Xóa</button></div>`).join('')}</div>`;
  }
  function catDelModal(id) {
    if (st.cats.length <= 1) { toast('Cần giữ lại ít nhất 1 danh mục'); return; }
    const c = catOf(id), n = st.items.filter(i => i.categoryId === id).length;
    const others = st.cats.filter(x => x.id !== id);
    openModal(`<h3>Xóa danh mục “${esc(c.name)}”</h3>
      ${n ? `<p>Có <b>${n}</b> mục trong danh mục này. Bạn muốn làm gì với chúng?</p>
      <select id="mvTo">${others.map(o => `<option value="${esc(o.id)}">Chuyển sang “${esc(o.name)}”</option>`).join('')}<option value="__del">🗑️ Xóa luôn các mục này</option></select>` : '<p>Danh mục đang trống.</p>'}
      <div class="row" style="justify-content:flex-end;margin-top:18px"><button class="ghost" data-act="m-cancel">Hủy</button><button class="btn bad" data-act="cat-del-ok" data-id="${esc(id)}">Xóa danh mục</button></div>`);
  }

  /* =====================================================
   *  DỮ LIỆU & CÀI ĐẶT
   * ===================================================== */
  const needsEnrich = i => !i.meaning || (i.type !== 'sentence' && !i.enriched);
  async function renderData() {
    const missing = st.items.filter(needsEnrich).length;
    const up = (typeof EngcloAnalytics !== 'undefined') ? await EngcloAnalytics.getUpdateInfo() : null;
    const cfg = (typeof EngcloAnalytics !== 'undefined') ? await EngcloAnalytics.getConfig() : {};
    const curVer = chrome.runtime.getManifest().version;
    const updateHTML = up && up.hasUpdate
      ? `<div class="fb no" style="margin-bottom:12px"><b>🎉 Đã có bản cập nhật v${esc(up.latestVersion)}!</b>
          <div style="margin-top:4px">${esc(up.changelog || '')}</div>
          ${up.downloadUrl ? `<div style="margin-top:8px"><a class="btn sm" href="${esc(up.downloadUrl)}" target="_blank" rel="noopener">⬇️ Tải bản mới</a></div>` : ''}
        </div>`
      : `<p class="muted" style="margin-bottom:8px">Bạn đang dùng bản mới nhất.</p>`;
    const safeNoteHTML = `
      <div style="margin-top:12px;padding:10px 12px;background:var(--soft);border-left:3px solid var(--pri);border-radius:0 8px 8px 0;font-size:13px;line-height:1.6">
        <b style="color:var(--pri)">⚠️ Lưu ý khi cập nhật để KHÔNG mất từ vựng đã lưu:</b>
        <div style="margin-top:4px">1. <b>Xuất file sao lưu (JSON)</b> ở mục bên dưới để dự phòng an toàn tuyệt đối.</div>
        <div>2. Tải bản mới và <b>giải nén đè trực tiếp</b> vào đúng thư mục Engclo đang dùng (chọn <i>Replace all files</i>). <b>TUYỆT ĐỐI KHÔNG</b> bấm nút <i>Remove / Xóa tiện ích</i> trên Chrome.</div>
        <div>3. Vào <code>chrome://extensions</code> bấm nút <b>Reload ↻</b> trên thẻ Engclo là xong. Toàn bộ từ vựng và cấp độ nhớ được giữ nguyên 100%.</div>
      </div>`;
    const gaPanel = st.settings.adminMode ? `
      <div class="panel"><h3>Thống kê người dùng (Google Analytics) — chế độ quản trị</h3>
        <p class="muted">Dán <b>Measurement ID</b> và <b>API Secret</b> từ tài khoản Google Analytics 4 của bạn để Engclo tự gửi thống kê cài mới / đang online / số từ đã lưu. Không cần server riêng. Giá trị chỉ lưu trên máy này.</p>
        <label class="f">Measurement ID (dạng G-XXXXXXXXXX)</label>
        <input type="text" id="gaId" value="${esc(cfg.measurementId || '')}" placeholder="G-XXXXXXXXXX">
        <label class="f">Measurement Protocol API Secret</label>
        <input type="text" id="gaSecret" value="${esc(cfg.apiSecret || '')}" placeholder="Dán API secret…">
        <label class="f">Link file version.json (kiểm tra cập nhật)</label>
        <input type="text" id="gaUrl" value="${esc(cfg.updateCheckUrl || '')}" placeholder="https://…/version.json">
        <div class="row" style="margin-top:10px"><button class="btn" data-act="ga-save">💾 Lưu cấu hình thống kê</button><span id="gaStatus" class="muted"></span></div></div>` : '';
    $('#view').innerHTML = `<h2>Dữ liệu & cài đặt</h2>
      <div class="panel"><h3>Phiên bản & cập nhật</h3>
        <p class="muted">Phiên bản hiện tại: <b data-act="ver-tap" title="Bấm 5 lần để mở chế độ quản trị">v${esc(curVer)}</b>${up && up.latestVersion ? ` · Mới nhất trên mạng: <b>v${esc(up.latestVersion)}</b>` : ''}${up && up.checkedAt ? ` · Kiểm tra lúc ${fmtDate(up.checkedAt)}` : ''}</p>
        ${updateHTML}
        <button class="ghost" data-act="check-update">🔄 Kiểm tra cập nhật ngay</button>
        ${safeNoteHTML}
      </div>
      ${gaPanel}
      <div class="panel"><h3>Cài đặt</h3>
        <label class="chk"><input type="checkbox" id="optEnabled" ${st.settings.enabled !== false ? 'checked' : ''}> Hiện icon ＋ khi bôi đen chữ trên trang web</label>
        <p class="muted">Phím tắt <b>Alt+S</b> (đổi tại <code>chrome://extensions/shortcuts</code>). Để dùng trên trang <code>file://</code>, bật “Cho phép truy cập URL của tệp” trong trang chi tiết extension.</p></div>
      <div class="panel"><h3>Tự động bổ sung dữ liệu</h3>
        <p class="muted">${missing ? `Có <b>${missing}</b> mục chưa có nghĩa / từ loại / ví dụ.` : 'Tất cả mục đã đầy đủ dữ liệu.'}</p>
        <div id="enrichBox"></div>
        <button class="btn" data-act="enrich-all" ${missing ? '' : 'disabled'}>✨ Bổ sung cho các mục còn thiếu</button></div>
      <div class="panel"><h3>Sao lưu & chuyển dữ liệu</h3>
        <div class="row"><button class="ghost" data-act="export-json">⬇️ Xuất JSON (sao lưu đầy đủ)</button>
        <button class="ghost" data-act="export-csv">⬇️ Xuất CSV (Excel)</button>
        <button class="ghost" data-act="import">⬆️ Nhập từ JSON</button></div></div>
      <div class="panel"><h3>Vùng nguy hiểm</h3><button class="ghost danger" data-act="wipe">🗑️ Xóa toàn bộ dữ liệu…</button></div>`;
  }
  function download(name, text, mime) {
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([text], { type: mime }));
    a.download = name; document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 3000);
  }
  const stamp = () => new Date().toISOString().slice(0, 10);
  function exportJSON() {
    download(`engclo-${stamp()}.json`, JSON.stringify({ version: 1, exportedAt: Date.now(), categories: st.cats, items: st.items }, null, 2), 'application/json');
  }
  function exportCSV() {
    const q = v => '"' + String(v == null ? '' : v).replace(/"/g, '""') + '"';
    const rows = [['Từ/Câu', 'Loại', 'Nghĩa', 'Từ loại', 'Phiên âm', 'Danh mục', 'Từ trọng tâm', 'Ví dụ', 'Ngữ cảnh', 'Ghi chú', 'Ngày lưu']];
    st.items.forEach(i => rows.push([
      i.text, TYPE_LABEL[i.type] || i.type, i.meaning, (i.pos || []).join(', '), i.phonetic, catOf(i.categoryId).name,
      (i.focus || []).join(', '), (i.examples || []).map(e => e.en + (e.vi ? ' (' + e.vi + ')' : '')).join(' | '),
      i.context, i.note, fmtDate(i.createdAt)
    ]));
    download(`engclo-${stamp()}.csv`, '﻿' + rows.map(r => r.map(q).join(',')).join('\r\n'), 'text/csv;charset=utf-8');
  }
  async function importJSON(file) {
    let data;
    try { data = JSON.parse(await file.text()); } catch (e) { toast('File JSON không hợp lệ'); return; }
    const items = Array.isArray(data) ? data : data && data.items;
    if (!Array.isArray(items)) { toast('Không tìm thấy dữ liệu từ vựng trong file'); return; }
    const cats = await VS.getCategories(), map = {};
    ((data && data.categories) || []).forEach(c => {
      if (!c || !c.name) return;
      let ex = cats.find(x => x.id === c.id) || cats.find(x => norm(x.name) === norm(c.name));
      if (!ex) { ex = { id: c.id || VS.uid(), name: String(c.name), color: c.color || VS.COLORS[cats.length % VS.COLORS.length] }; cats.push(ex); }
      map[c.id] = ex.id;
    });
    await VS.saveCategories(cats);
    const cur = await VS.getItems();
    const keys = new Set(cur.map(i => i.type + '|' + norm(i.text))), ids = new Set(cur.map(i => i.id));
    const add = []; let skipped = 0;
    for (const raw of items) {
      if (!raw || !raw.text) continue;
      const type = ['word', 'phrase', 'sentence'].includes(raw.type) ? raw.type : 'word';
      const key = type + '|' + norm(raw.text);
      if (keys.has(key)) { skipped++; continue; }
      keys.add(key);
      const it = Object.assign(VS.newItem({ type, text: String(raw.text) }), raw, { type });
      if (!it.id || ids.has(it.id)) it.id = VS.uid();
      ids.add(it.id);
      it.categoryId = map[raw.categoryId] || (cats.some(c => c.id === raw.categoryId) ? raw.categoryId : cats[0].id);
      it.srs = Object.assign({ box: 0, due: 0, correct: 0, wrong: 0, last: 0 }, raw.srs || {});
      add.push(it);
    }
    await VS.putItems(add);
    toast(`Đã nhập ${add.length} mục${skipped ? ` (bỏ qua ${skipped} mục trùng)` : ''}`);
    await load(); renderStats(); render();
  }
  async function enrichAll() {
    if (st.enrichRun) return;
    const todo = st.items.filter(needsEnrich).map(i => i.id);
    st.enrichRun = { stop: false };
    let ok = 0, fail = 0;
    for (let k = 0; k < todo.length; k++) {
      if (st.enrichRun.stop) break;
      const box = $('#enrichBox');
      if (box) box.innerHTML = `<div class="progress"><div style="width:${k / todo.length * 100}%"></div></div>
        <div class="muted" style="margin-bottom:10px">Đang xử lý ${k + 1}/${todo.length}… <button class="ghost sm" data-act="enrich-stop">Dừng</button></div>`;
      const r = await sendMsg({ type: 'enrich', id: todo[k] });
      if (r && r.ok) ok++; else fail++;
      await sleep(250);
    }
    st.enrichRun = null;
    toast(`Xong: ${ok} thành công${fail ? `, ${fail} lỗi (kiểm tra mạng)` : ''}`);
    await load(); renderStats();
    if (st.view === 'data') renderData();
  }

  /* =====================================================
   *  SỰ KIỆN
   * ===================================================== */
  $('#nav').addEventListener('click', e => {
    const b = e.target.closest('button[data-view]');
    if (!b) return;
    st.flash = null; st.quiz = null;
    go(b.dataset.view);
  });
  window.addEventListener('hashchange', () => {
    const h = location.hash.replace('#', '');
    if (VIEWS.includes(h) && h !== st.view) { st.flash = null; st.quiz = null; go(h); }
  });

  $('#view').addEventListener('click', async e => {
    const el = e.target.closest('[data-act]');
    if (!el || el.tagName === 'INPUT') return;
    const act = el.dataset.act;
    const card = el.closest('[data-id]');
    const id = card && card.dataset.id;
    const item = id && st.items.find(i => i.id === id);
    switch (act) {
      // thư viện
      case 'add': editModal(null); break;
      case 'filter-cat': st.f.cat = el.dataset.cat; st.f.limit = 60; renderLibrary(); break;
      case 'more': st.f.limit += 60; renderList(); break;
      case 'speak': if (item) VS.speak(item.text, item.type === 'sentence' ? '' : item.audio); break;
      case 'edit': if (item) editModal(item); break;
      case 'del':
        if (item && confirm('Xóa “' + item.text.slice(0, 60) + '”?')) {
          await VS.deleteItems([item.id]); toast('Đã xóa'); await load(); renderStats(); renderLibrary();
        }
        break;
      case 'enrich': {
        if (!item) break;
        el.disabled = true; el.textContent = '…';
        const r = await sendMsg({ type: 'enrich', id: item.id, force: true });
        toast(r && r.ok ? 'Đã cập nhật dữ liệu' : 'Không lấy được dữ liệu — kiểm tra kết nối mạng');
        await load(); renderStats(); if (st.view === 'library') renderList();
        break;
      }
      case 'bulk-clear': st.f.sel.clear(); renderList(); break;
      case 'bulk-move': {
        const to = $('#bulkCat').value, ids = [...st.f.sel];
        for (const x of ids) await VS.updateItem(x, { categoryId: to });
        toast(`Đã chuyển ${ids.length} mục`); st.f.sel.clear(); await load(); renderLibrary();
        break;
      }
      case 'bulk-del': {
        const ids = [...st.f.sel];
        if (confirm(`Xóa ${ids.length} mục đã chọn?`)) {
          await VS.deleteItems(ids); st.f.sel.clear(); toast('Đã xóa'); await load(); renderStats(); renderLibrary();
        }
        break;
      }
      // flashcard
      case 'f-start': flashFromConfig(); break;
      case 'f-flip': flashFlip(); break;
      case 'f-grade': flashGrade(el.dataset.g); break;
      case 'f-speak': { const c = st.flash && st.flash.deck[st.flash.i]; if (c) VS.speak(c.text, c.type === 'sentence' ? '' : c.audio); break; }
      case 'f-exit': st.flash = null; renderFlash(); break;
      case 'f-retry': startFlash(shuffle(st.flash.again.slice()), st.flash.dir); break;
      // quiz
      case 'q-start': {
        const kinds = $$('.qk').filter(c => c.checked).map(c => c.value);
        if (!kinds.length) { toast('Hãy chọn ít nhất một dạng câu hỏi'); break; }
        startQuiz({ cat: $('#qzCat').value, count: +$('#qzCount').value, time: +$('#qzTime').value, kinds });
        break;
      }
      case 'q-opt': { const q = st.quiz.qs[st.quiz.i], k = +el.dataset.k; answerQuestion(q.options[k], k); break; }
      case 'q-check': { const v = $('#qAns').value; if (v.trim()) answerQuestion(v, -1); break; }
      case 'q-hint': {
        const q = st.quiz.qs[st.quiz.i];
        st.quiz.hint = true;
        $('#qfb').innerHTML = `<div class="muted" style="margin-top:10px">💡 Bắt đầu bằng “<b>${esc(q.answer[0])}</b>”, dài ${q.answer.length} ký tự.</div>`;
        break;
      }
      case 'q-next': nextQuestion(); break;
      case 'q-speak': { const q = st.quiz.qs[st.quiz.i]; VS.speak(q.item.text, q.item.type === 'sentence' ? '' : q.item.audio); break; }
      case 'q-exit': stopQuizTimer(); st.quiz = null; renderQuiz(); break;
      case 'q-retry': { const c = st.quiz.cfg; stopQuizTimer(); startQuiz(c); break; }
      case 'q-retry-wrong': { const c = st.quiz.cfg, only = st.quiz.wrong.map(w => w.q.item); startQuiz(c, only); break; }
      // danh mục
      case 'cat-add': {
        const n = $('#newCatName').value.trim();
        if (!n) break;
        await VS.addCategory(n); toast('Đã thêm danh mục'); await load(); renderCats();
        break;
      }
      case 'cat-del': catDelModal(el.closest('[data-cid]').dataset.cid); break;
      // dữ liệu
      case 'export-json': exportJSON(); break;
      case 'export-csv': exportCSV(); break;
      case 'import': $('#impFile').click(); break;
      case 'enrich-all': enrichAll(); break;
      case 'enrich-stop': if (st.enrichRun) st.enrichRun.stop = true; break;
      case 'check-update': {
        el.disabled = true; el.textContent = 'Đang kiểm tra…';
        const r = await sendMsg({ type: 'checkUpdate' });
        el.disabled = false; el.textContent = '🔄 Kiểm tra cập nhật ngay';
        const info = r && r.ok && r.data ? r.data : null;
        if (info && info.hasUpdate) { toast('Có bản mới: v' + info.latestVersion); renderData(); }
        else toast(info ? 'Bạn đang dùng bản mới nhất (v' + info.currentVersion + ')' : 'Không kiểm tra được — xem lại link version.json');
        break;
      }
      case 'ver-tap': {
        const now = Date.now();
        st.verTaps = (now - (st.verLast || 0) < 1500) ? (st.verTaps || 0) + 1 : 1;
        st.verLast = now;
        if (st.verTaps >= 5) {
          st.verTaps = 0;
          st.settings = await VS.setSettings({ adminMode: !st.settings.adminMode });
          toast(st.settings.adminMode ? 'Đã bật chế độ quản trị' : 'Đã tắt chế độ quản trị');
          renderData();
        }
        break;
      }
      case 'ga-save': {
        const cfg = await EngcloAnalytics.setConfig({
          measurementId: $('#gaId').value.trim(),
          apiSecret: $('#gaSecret').value.trim(),
          updateCheckUrl: $('#gaUrl').value.trim()
        });
        const st2 = $('#gaStatus');
        if (st2) st2.textContent = cfg.measurementId ? '✓ Đã bật thống kê GA4' : '✓ Đã lưu (thống kê đang tắt vì chưa có Measurement ID)';
        toast('Đã lưu cấu hình thống kê');
        EngcloAnalytics.track('config_saved', {});
        break;
      }
      case 'wipe':
        if (confirm('Xóa TOÀN BỘ từ vựng và danh mục? Hành động này không thể hoàn tác.') && confirm('Chắc chắn chứ? Hãy xuất file sao lưu trước nếu cần.')) {
          await chrome.storage.local.clear();
          await load(); renderStats(); toast('Đã xóa toàn bộ dữ liệu'); render();
        }
        break;
    }
  });

  $('#view').addEventListener('change', async e => {
    const t = e.target, act = t.dataset.act;
    if (act === 'sel') {
      const id = t.closest('[data-id]').dataset.id;
      if (t.checked) st.f.sel.add(id); else st.f.sel.delete(id);
      renderList();
    } else if (act === 'sel-all') {
      const all = filtered();
      if (t.checked) all.forEach(i => st.f.sel.add(i.id)); else all.forEach(i => st.f.sel.delete(i.id));
      renderList();
    } else if (t.id === 'ftype') { st.f.type = t.value; st.f.limit = 60; renderList(); }
    else if (t.id === 'flevel') { st.f.level = t.value; st.f.limit = 60; renderList(); }
    else if (t.id === 'fsort') { st.f.sort = t.value; renderList(); }
    else if (act === 'cat-color' || act === 'cat-name') {
      const cid = t.closest('[data-cid]').dataset.cid;
      const cats = await VS.getCategories();
      const c = cats.find(x => x.id === cid);
      if (!c) return;
      if (act === 'cat-color') c.color = t.value;
      else { const v = t.value.trim(); if (!v) { t.value = c.name; return; } c.name = v; }
      await VS.saveCategories(cats);
      st.cats = cats; toast('Đã lưu danh mục');
    } else if (t.id === 'optEnabled') {
      await VS.setSettings({ enabled: t.checked });
      st.settings.enabled = t.checked;
      toast(t.checked ? 'Đã bật icon khi bôi đen' : 'Đã tắt icon khi bôi đen');
    }
  });
  $('#view').addEventListener('input', e => {
    if (e.target.id === 'fq') { st.f.q = e.target.value; st.f.limit = 60; renderList(); }
  });
  $('#view').addEventListener('keydown', e => {
    if (e.target.id === 'newCatName' && e.key === 'Enter') { const b = $('[data-act="cat-add"]'); if (b) b.click(); }
  });

  $('#modal').addEventListener('click', async e => {
    if (e.target.classList.contains('mback')) { closeModal(); return; }
    const el = e.target.closest('[data-act]');
    if (!el) return;
    if (el.dataset.act === 'm-cancel') closeModal();
    else if (el.dataset.act === 'm-save') modalSave();
    else if (el.dataset.act === 'cat-del-ok') {
      const id = el.dataset.id, mv = $('#mvTo'), ids = st.items.filter(i => i.categoryId === id).map(i => i.id);
      if (mv && ids.length) {
        if (mv.value === '__del') await VS.deleteItems(ids);
        else for (const x of ids) await VS.updateItem(x, { categoryId: mv.value });
      }
      await VS.saveCategories(st.cats.filter(c => c.id !== id));
      if (st.f.cat === id) st.f.cat = 'all';
      closeModal(); toast('Đã xóa danh mục');
      await load(); renderStats(); renderCats();
    }
  });

  $('#impFile').addEventListener('change', async e => {
    const f = e.target.files && e.target.files[0];
    e.target.value = '';
    if (f) await importJSON(f);
  });

  // Phóng to ảnh QR khi click & copy số tài khoản
  const qrImg = $('#qrPreview');
  if (qrImg) {
    qrImg.addEventListener('click', () => {
      openModal(`
        <div style="text-align:center">
          <h3 style="margin-top:0">Quét mã QR để ủng hộ tác giả</h3>
          <img src="icons/qr-donate.png" alt="QR Donate" style="max-width:320px;width:100%;border-radius:12px;box-shadow:0 8px 24px rgba(0,0,0,.15);background:#fff;padding:8px">
          <div style="margin-top:12px"><b>TPBank:</b> <code>0324 0114 001</code> — VU DUC NGUYEN</div>
          <div style="margin-top:16px"><button class="btn" data-act="m-cancel">Đóng</button></div>
        </div>
      `);
    });
  }
  const bankCode = $('.bank-meta code');
  if (bankCode) {
    bankCode.title = 'Bấm để sao chép';
    bankCode.style.cursor = 'pointer';
    bankCode.addEventListener('click', async () => {
      try {
        await navigator.clipboard.writeText('03240114001');
        toast('Đã sao chép số tài khoản: 03240114001');
      } catch (e) { toast('Số TK: 0324 0114 001'); }
    });
  }

  document.addEventListener('keydown', e => {
    if (e.key === 'Escape' && modalOpen()) { closeModal(); return; }
    if (modalOpen()) return;
    const tag = (e.target.tagName || '').toLowerCase();
    const typing = tag === 'input' || tag === 'textarea' || tag === 'select';
    if (st.view === 'flash' && st.flash && st.flash.i < st.flash.deck.length && !typing) {
      if (e.key === ' ' || e.key === 'Enter') { e.preventDefault(); flashFlip(); }
      else if (e.key === '1') flashGrade('again');
      else if (e.key === '2') flashGrade('hard');
      else if (e.key === '3') flashGrade('good');
    } else if (st.view === 'quiz' && st.quiz && !st.quiz.done) {
      const qz = st.quiz, q = qz.qs[qz.i];
      if (e.target.id === 'qAns' && e.key === 'Enter') {
        e.preventDefault();
        if (qz.answered) nextQuestion(); else if (e.target.value.trim()) answerQuestion(e.target.value, -1);
      } else if (!typing) {
        if (qz.answered && e.key === 'Enter') { e.preventDefault(); nextQuestion(); }
        else if (!qz.answered && q.options && /^[1-9]$/.test(e.key) && +e.key <= q.options.length) answerQuestion(q.options[+e.key - 1], +e.key - 1);
      }
    }
  });

  // Cập nhật tự động khi dữ liệu thay đổi (lưu từ trang web, bổ sung dịch…)
  let refT;
  chrome.storage.onChanged.addListener((ch, area) => {
    if (area !== 'local') return;
    clearTimeout(refT);
    refT = setTimeout(async () => {
      await load(); renderStats();
      if (modalOpen()) return;
      if (st.view === 'library') {
        if (document.activeElement && document.activeElement.id === 'fq') renderList(); else renderLibrary();
      } else if (st.view === 'cats') {
        const a = document.activeElement;
        if (!(a && a.tagName === 'INPUT')) renderCats();
      }
    }, 300);
  });

  (async function init() {
    await load(); renderStats();
    const h = location.hash.replace('#', '');
    go(VIEWS.includes(h) ? h : 'library');
    try {
      chrome.runtime.sendMessage({ type: 'track', event: 'open_manage', params: { items: st.items.length } });
    } catch (e) { /* bỏ qua */ }
  })();
})();
