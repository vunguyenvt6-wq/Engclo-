/* Engclo – content script: icon khi bôi đen, bảng lưu từ/câu, danh mục, highlight từ trọng tâm */
(function () {
  'use strict';
  if (window.__vsInjected) return;
  if (window !== window.top && (window.innerWidth < 320 || window.innerHeight < 220)) return;
  window.__vsInjected = true;

  const MAX_LEN = 600;
  const alive = () => { try { return !!(chrome.runtime && chrome.runtime.id); } catch (e) { return false; } };

  let enabled = true;
  let host = null, root = null, iconEl = null, panelEl = null;
  let pending = null; // {text, range, rect}
  let S = null;       // trạng thái bảng đang mở
  let seq = 0;

  try {
    chrome.storage.local.get('settings').then(r => { enabled = !(r.settings && r.settings.enabled === false); });
    chrome.storage.onChanged.addListener((ch, area) => {
      if (area === 'local' && ch.settings) {
        enabled = !(ch.settings.newValue && ch.settings.newValue.enabled === false);
        if (!enabled) { hideIcon(); closePanel(); }
      }
    });
  } catch (e) { /* extension vừa được nạp lại */ }

  /* ================= CSS (trong Shadow DOM) ================= */
  const CSS = `
  :host{all:initial}
  *{box-sizing:border-box;font-family:Arial,"Helvetica Neue",Helvetica,sans-serif}
  [hidden]{display:none!important}
  .icon{position:fixed;width:34px;height:34px;border-radius:50%;background:#ffffff;border:2px solid #2e7d32;
    box-shadow:0 4px 14px rgba(46,125,50,.35);cursor:pointer;display:flex;align-items:center;justify-content:center;
    padding:0;animation:pop .14s ease-out;transition:transform .1s,box-shadow .1s;overflow:hidden}
  .icon:hover{transform:scale(1.15);box-shadow:0 6px 18px rgba(46,125,50,.5)}
  .icon img{width:24px;height:24px;display:block;pointer-events:none;user-select:none}
  @keyframes pop{from{transform:scale(.4);opacity:0}to{transform:scale(1);opacity:1}}
  .panel{--bg:#fff;--fg:#1f2937;--muted:#556b2f;--line:#dbe5dc;--soft:#eef4ee;--pri:#2e7d32;--hl:#c8e6c9;--hlfg:#1b5e20;
    position:fixed;width:370px;max-width:calc(100vw - 16px);max-height:min(640px,calc(100vh - 16px));display:flex;flex-direction:column;
    background:var(--bg);color:var(--fg);border:1px solid var(--line);border-radius:14px;
    box-shadow:0 16px 48px rgba(0,0,0,.3);font-size:14px;line-height:1.45;animation:pop .14s ease-out}
  @media (prefers-color-scheme:dark){.panel{--bg:#16241a;--fg:#edf2ee;--muted:#95a898;--line:#243a2b;--soft:#101d14;--pri:#66bb6a;--hl:#254a2a;--hlfg:#c8e6c9}}
  .hd{display:flex;align-items:center;justify-content:space-between;gap:8px;padding:10px 12px;border-bottom:1px solid var(--line)}
  .ttl{font-weight:700;font-size:14px;color:var(--pri);display:inline-flex;align-items:center;gap:6px}
  .ttl img{width:18px;height:18px;object-fit:contain;display:block}
  .hd-r{display:flex;align-items:center;gap:6px}
  .bd{padding:12px;overflow:auto;display:flex;flex-direction:column;gap:8px}
  .ft{display:flex;justify-content:space-between;align-items:center;gap:8px;padding:10px 12px;border-top:1px solid var(--line)}
  select,input[type=text],textarea{width:100%;padding:7px 9px;border:1px solid var(--line);border-radius:8px;background:var(--bg);color:var(--fg);font-size:14px;outline:none}
  select:focus,input:focus,textarea:focus{border-color:var(--pri)}
  .hd select{width:auto;padding:4px 6px;font-size:12px}
  textarea{resize:vertical;min-height:52px}
  button{font-family:inherit}
  .x{border:0;background:transparent;font-size:16px;cursor:pointer;color:var(--muted);padding:2px 6px;border-radius:6px}
  .x:hover{background:var(--soft)}
  .btn{border:0;background:var(--pri);color:#fff;border-radius:8px;padding:8px 16px;font-size:14px;font-weight:600;cursor:pointer}
  .btn:hover{filter:brightness(1.1)}.btn:disabled{opacity:.6;cursor:default}
  .ghost{border:1px solid var(--line);background:transparent;color:var(--fg);border-radius:8px;padding:7px 10px;font-size:13px;cursor:pointer;white-space:nowrap}
  .ghost:hover{border-color:var(--pri);color:var(--pri)}
  .row{display:flex;gap:6px;align-items:center}
  .lbl{font-size:12px;font-weight:600;color:var(--muted);text-transform:uppercase;letter-spacing:.03em;display:flex;align-items:center;gap:6px}
  .term{display:flex;align-items:center;gap:8px;flex-wrap:wrap}
  .word{font-size:20px;font-weight:700;color:var(--pri);word-break:break-word}
  .ph{color:var(--muted);font-size:13px}
  .spk{border:0;background:var(--soft);border-radius:50%;width:28px;height:28px;cursor:pointer;font-size:14px;flex:none}
  .spk:hover{background:var(--line)}
  .hint{font-size:12px;color:var(--muted)}
  .chips{display:flex;flex-wrap:wrap;gap:4px;margin-top:4px;padding:8px;background:var(--soft);border-radius:10px}
  .chip{border:1px solid transparent;background:transparent;color:var(--fg);border-radius:6px;padding:2px 5px;font-size:15px;cursor:pointer}
  .chip:hover{background:var(--line)}
  .chip.on{background:var(--hl);color:var(--hlfg);font-weight:700;border-color:#43a047}
  .spin{width:12px;height:12px;border:2px solid var(--line);border-top-color:var(--pri);border-radius:50%;animation:sp .7s linear infinite;display:inline-block}
  @keyframes sp{to{transform:rotate(360deg)}}
  .err{font-size:12px;color:#b45309;background:#fef3c7;border-radius:8px;padding:6px 8px}
  .mrow{font-size:13px;margin:2px 0}
  .tag{display:inline-block;background:var(--soft);color:var(--pri);border-radius:5px;padding:0 6px;font-size:11px;font-weight:700;margin-right:4px}
  .def{color:var(--muted);font-size:12px;margin-left:2px}
  .exrow{font-size:13px;border-left:3px solid var(--pri);padding:2px 8px;margin:4px 0;background:var(--soft);border-radius:0 6px 6px 0}
  .exrow .vi{color:var(--muted);font-size:12px}
  .ctx{font-size:13px;background:var(--soft);border-radius:8px;padding:6px 8px}
  mark{background:var(--hl);color:var(--hlfg);border-radius:3px;padding:0 2px}
  .chk{display:flex;gap:6px;align-items:center;font-size:13px;cursor:pointer}
  .toast{color:#2e7d32;font-weight:600;font-size:13px}
  `;

  /* ================= Tiện ích ================= */
  function ensureHost() {
    if (host && host.isConnected) return;
    host = document.createElement('vs-host');
    host.style.cssText = 'all:initial!important;position:fixed!important;top:0!important;left:0!important;width:0!important;height:0!important;z-index:2147483647!important;';
    root = host.attachShadow({ mode: 'open' });
    const st = document.createElement('style');
    st.textContent = CSS;
    root.appendChild(st);
    document.documentElement.appendChild(host);
    iconEl = null; panelEl = null;
  }
  const q = sel => panelEl.querySelector(sel);
  const inHost = e => { try { return !!host && e.composedPath().includes(host); } catch (err) { return false; } };

  function cleanTerm(t) {
    return String(t).replace(/\s+/g, ' ').replace(/^[^A-Za-z0-9]+|[^A-Za-z0-9.!?]+$/g, '').replace(/[.!?]+$/, '').trim();
  }
  function detectType(t) {
    const n = t.split(/\s+/).filter(Boolean).length;
    if (n === 1) return 'word';
    if (n <= 4 && !/[.!?;:]/.test(t)) return 'phrase';
    return 'sentence';
  }
  function rectOf(range, ev) {
    let r = null;
    try {
      const rs = range.getClientRects();
      r = rs.length ? rs[rs.length - 1] : range.getBoundingClientRect();
    } catch (e) { /* range không hợp lệ */ }
    if ((!r || (!r.width && !r.height)) && ev) {
      return { left: ev.clientX, right: ev.clientX, top: ev.clientY, bottom: ev.clientY };
    }
    if (!r) return { left: window.innerWidth / 2 - 150, right: window.innerWidth / 2, top: 80, bottom: 90 };
    return { left: r.left, right: r.right, top: r.top, bottom: r.bottom };
  }

  // Lấy câu chứa phần được chọn
  function getContext(range, selText) {
    try {
      let el = range.commonAncestorContainer;
      if (el.nodeType === 3) el = el.parentElement;
      let anc = el;
      for (let i = 0; i < 6 && anc && anc.parentElement; i++) {
        const t = anc.textContent || '';
        if (t.length >= selText.length + 30 && /^(P|LI|DIV|TD|TH|BLOCKQUOTE|H[1-6]|ARTICLE|SECTION|DD|DT|PRE|FIGCAPTION)$/.test(anc.tagName)) break;
        anc = anc.parentElement;
      }
      if (!anc) return '';
      let full = anc.textContent || '';
      let idx;
      if (full.length > 20000) {
        const n = range.startContainer;
        if (n.nodeType !== 3) return '';
        full = n.textContent; idx = range.startOffset;
      } else {
        const pre = document.createRange();
        pre.selectNodeContents(anc);
        pre.setEnd(range.startContainer, range.startOffset);
        idx = pre.toString().length;
      }
      const rawLen = Math.max(range.toString().length, selText.length);
      let start = 0;
      for (let i = idx - 1; i >= 0; i--) {
        const ch = full[i];
        if ((ch === '.' || ch === '!' || ch === '?' || ch === '\n') && (i + 1 >= idx || /\s/.test(full[i + 1]))) { start = i + 1; break; }
      }
      let end = full.length;
      for (let j = idx + rawLen; j < full.length; j++) {
        const ch = full[j];
        if ((ch === '.' || ch === '!' || ch === '?') && (j + 1 >= full.length || /\s/.test(full[j + 1]))) { end = j + 1; break; }
        if (ch === '\n') { end = j; break; }
      }
      let s = full.slice(start, end).replace(/\s+/g, ' ').trim();
      if (s.length <= selText.length + 3) return '';
      if (s.length > 400) {
        const p = Math.max(0, s.toLowerCase().indexOf(selText.toLowerCase()));
        const a = Math.max(0, p - 180), b = Math.min(s.length, p + selText.length + 180);
        s = (a > 0 ? '… ' : '') + s.slice(a, b) + (b < s.length ? ' …' : '');
      }
      return s;
    } catch (e) { return ''; }
  }

  /* ================= Icon khi bôi đen ================= */
  function showIcon(rect) {
    ensureHost();
    if (!iconEl) {
      iconEl = document.createElement('button');
      iconEl.className = 'icon';
      iconEl.title = 'Lưu vào Engclo';
      const iconUrl = alive() ? chrome.runtime.getURL('icons/icon48.png') : '';
      iconEl.innerHTML = iconUrl
        ? `<img src="${iconUrl}" alt="🍀">`
        : '<span style="font-size:18px;line-height:1">🍀</span>';
      iconEl.addEventListener('mousedown', e => { e.preventDefault(); e.stopPropagation(); });
      iconEl.addEventListener('click', e => {
        e.preventDefault(); e.stopPropagation();
        if (pending) openPanel(pending.text, pending.range, pending.rect);
      });
    }
    const x = Math.min(Math.max(6, rect.right + 4), window.innerWidth - 44);
    const y = Math.min(Math.max(6, rect.bottom + 6), window.innerHeight - 44);
    iconEl.style.left = x + 'px';
    iconEl.style.top = y + 'px';
    if (!iconEl.isConnected) root.appendChild(iconEl);
  }
  function hideIcon() { if (iconEl && iconEl.isConnected) iconEl.remove(); }

  function checkSelection(ev) {
    if (!enabled || !alive()) return;
    const sel = window.getSelection();
    if (!sel || sel.isCollapsed || !sel.rangeCount) { hideIcon(); pending = null; return; }
    const text = sel.toString().replace(/\s+/g, ' ').trim();
    if (!text || text.length > MAX_LEN || !/[A-Za-z]/.test(text)) { hideIcon(); pending = null; return; }
    const range = sel.getRangeAt(0).cloneRange();
    const rect = rectOf(range, ev);
    pending = { text, range, rect };
    showIcon(rect);
  }

  document.addEventListener('mouseup', e => {
    if (inHost(e)) return;
    setTimeout(() => checkSelection(e), 15);
  }, true);
  document.addEventListener('keyup', e => {
    if (inHost(e)) return;
    if (e.shiftKey && /^(Arrow|Home|End|Page)/.test(e.key)) setTimeout(() => checkSelection(null), 15);
  }, true);
  document.addEventListener('mousedown', e => {
    if (inHost(e)) return;
    hideIcon();
    if (panelEl && !(S && S.edited)) closePanel();
  }, true);
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') { hideIcon(); closePanel(); }
  }, true);
  window.addEventListener('scroll', e => { if (!inHost(e)) hideIcon(); }, true);

  /* ================= Bảng lưu ================= */
  function buildPanel() {
    if (panelEl && panelEl.isConnected) panelEl.remove();
    panelEl = document.createElement('div');
    panelEl.className = 'panel';
    const logoUrl = alive() ? chrome.runtime.getURL('icons/icon48.png') : '';
    const logoHTML = logoUrl ? `<img src="${logoUrl}" alt="Logo">` : '🍀';
    panelEl.innerHTML = `
      <div class="hd">
        <div class="ttl">${logoHTML}<span>Engclo</span></div>
        <div class="hd-r">
          <select id="type" title="Loại"><option value="word">Từ</option><option value="phrase">Cụm từ</option><option value="sentence">Câu</option></select>
          <button class="x" id="close" title="Đóng (Esc)">✕</button>
        </div>
      </div>
      <div class="bd">
        <div class="term" id="termRow">
          <span class="word" id="wordTxt"></span>
          <button class="spk" id="spk" title="Phát âm">🔊</button>
          <span class="ph" id="ph"></span>
        </div>
        <div id="sentBox" hidden>
          <div class="row" style="justify-content:space-between">
            <span class="hint">Bấm vào các từ để <b>đánh dấu từ trọng tâm</b></span>
            <button class="spk" id="spk2" title="Đọc cả câu">🔊</button>
          </div>
          <div class="chips" id="chips"></div>
        </div>
        <label class="lbl">Nghĩa / bản dịch <span class="spin" id="spin"></span></label>
        <textarea id="meaning" rows="2" placeholder="Đang tự động dịch…"></textarea>
        <div class="err" id="err" hidden></div>
        <div id="posBox"></div>
        <div id="exBox"></div>
        <label class="chk" id="ctxRow" hidden><input type="checkbox" id="ctxChk" checked><span>Lưu kèm câu chứa từ này (highlight từ trong câu)</span></label>
        <div class="ctx" id="ctxPrev" hidden></div>
        <label class="lbl">Danh mục</label>
        <div class="row"><select id="cat"></select><button class="ghost" id="newCatBtn" type="button">＋ Mới</button></div>
        <div class="row" id="newCatRow" hidden>
          <input type="text" id="newCat" placeholder="Tên danh mục mới…" maxlength="40">
          <button class="ghost" id="addCat" type="button">Thêm</button>
        </div>
      </div>
      <div class="ft">
        <button class="ghost" id="openMgr" type="button">📚 Kho từ vựng</button>
        <span class="toast" id="toast"></span>
        <button class="btn" id="save" type="button">Lưu</button>
      </div>`;
    ['keydown', 'keyup', 'keypress'].forEach(t => panelEl.addEventListener(t, e => e.stopPropagation()));
    root.appendChild(panelEl);

    q('#close').addEventListener('click', closePanel);
    q('#type').addEventListener('change', e => { S.type = e.target.value; S.edited = false; q('#meaning').value = ''; applyType(); doLookup(); });
    q('#spk').addEventListener('click', () => VS.speak(S.text, S.lookup && S.lookup.audio));
    q('#spk2').addEventListener('click', () => VS.speak(S.text));
    q('#meaning').addEventListener('input', () => { S.edited = true; });
    q('#newCatBtn').addEventListener('click', () => { const r = q('#newCatRow'); r.hidden = !r.hidden; if (!r.hidden) q('#newCat').focus(); });
    q('#addCat').addEventListener('click', addCat);
    q('#newCat').addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); addCat(); } });
    q('#save').addEventListener('click', save);
    q('#openMgr').addEventListener('click', () => { try { chrome.runtime.sendMessage({ type: 'openManage' }); } catch (e) { /* bỏ qua */ } });
    q('#ctxChk').addEventListener('change', () => { q('#ctxPrev').hidden = !(S.context && q('#ctxChk').checked); });
  }

  function place() {
    if (!panelEl || !S) return;
    const r = S.rect, w = panelEl.offsetWidth || 370, h = panelEl.offsetHeight || 320;
    const left = Math.min(Math.max(8, r.left), Math.max(8, window.innerWidth - w - 8));
    let top = r.bottom + 12;
    if (top + h > window.innerHeight - 8) {
      const above = r.top - h - 12;
      top = above >= 8 ? above : Math.max(8, window.innerHeight - h - 8);
    }
    panelEl.style.left = left + 'px';
    panelEl.style.top = top + 'px';
  }

  async function openPanel(text, range, rect) {
    if (!alive()) return;
    ensureHost();
    hideIcon();
    const type = detectType(text);
    const term = type === 'sentence' ? text : cleanTerm(text);
    if (!term) return;
    const context = type !== 'sentence' && range ? getContext(range, term) : '';
    let cats, settings;
    try { [cats, settings] = await Promise.all([VS.getCategories(), VS.getSettings()]); } catch (e) { return; }
    S = {
      text: term, type, context, cats, rect: rect || { left: 40, right: 40, top: 60, bottom: 70 },
      catId: (settings.lastCategoryId && cats.some(c => c.id === settings.lastCategoryId)) ? settings.lastCategoryId : cats[0].id,
      focus: new Set(), edited: false, lookup: null
    };
    buildPanel();
    q('#type').value = type;
    fillCats(S.catId);
    applyType();
    place();
    doLookup();
  }
  function closePanel() {
    seq++;
    if (panelEl && panelEl.isConnected) panelEl.remove();
    panelEl = null; S = null;
  }

  function fillCats(selectedId) {
    const sel = q('#cat');
    sel.innerHTML = '';
    S.cats.forEach(c => {
      const o = document.createElement('option');
      o.value = c.id; o.textContent = c.name;
      sel.appendChild(o);
    });
    sel.value = selectedId || S.cats[0].id;
  }
  async function addCat() {
    const name = q('#newCat').value.trim();
    if (!name) return;
    try {
      const c = await VS.addCategory(name);
      S.cats = await VS.getCategories();
      fillCats(c.id);
      q('#newCat').value = '';
      q('#newCatRow').hidden = true;
    } catch (e) { /* bỏ qua */ }
  }

  function applyType() {
    const isS = S.type === 'sentence';
    q('#termRow').hidden = isS;
    q('#sentBox').hidden = !isS;
    q('#wordTxt').textContent = S.text;
    q('#ph').textContent = '';
    q('#spk').hidden = false;
    if (isS) buildChips();
    q('#ctxRow').hidden = isS || !S.context;
    q('#ctxPrev').hidden = true;
    if (!isS && S.context) {
      q('#ctxPrev').innerHTML = VS.markHTML(S.context, [S.text]);
      q('#ctxPrev').hidden = !q('#ctxChk').checked;
    }
    q('#posBox').innerHTML = '';
    q('#exBox').innerHTML = '';
    q('#meaning').placeholder = 'Đang tự động dịch…';
  }

  function buildChips() {
    const box = q('#chips');
    box.innerHTML = '';
    S.text.split(/\s+/).forEach((tok, i) => {
      const b = document.createElement('button');
      b.type = 'button';
      b.className = 'chip' + (S.focus.has(i) ? ' on' : '');
      b.textContent = tok;
      b.addEventListener('click', () => {
        if (S.focus.has(i)) S.focus.delete(i); else S.focus.add(i);
        b.classList.toggle('on');
      });
      box.appendChild(b);
    });
  }
  function focusTerms() {
    const toks = S.text.split(/\s+/);
    const idx = [...S.focus].sort((a, b) => a - b);
    const groups = [];
    let cur = [];
    idx.forEach((i, k) => {
      if (k > 0 && i === idx[k - 1] + 1) cur.push(i);
      else { if (cur.length) groups.push(cur); cur = [i]; }
    });
    if (cur.length) groups.push(cur);
    return groups.map(g => VS.cleanWord(g.map(i => toks[i]).join(' '))).filter(Boolean);
  }

  /* ---------- Tra cứu tự động ---------- */
  function doLookup() {
    const my = ++seq;
    S.lookup = null;
    q('#spin').hidden = false;
    q('#err').hidden = true;
    try {
      chrome.runtime.sendMessage({ type: 'lookup', text: S.text, itemType: S.type }, resp => {
        const lastErr = chrome.runtime.lastError;
        if (my !== seq || !panelEl) return;
        q('#spin').hidden = true;
        if (lastErr || !resp || !resp.ok) {
          q('#err').hidden = false;
          q('#err').textContent = 'Không dịch được tự động (kiểm tra mạng). Bạn vẫn có thể tự nhập nghĩa rồi lưu — extension sẽ bổ sung sau.';
          q('#meaning').placeholder = 'Nhập nghĩa…';
          return;
        }
        S.lookup = resp.data;
        fillLookup();
      });
    } catch (e) {
      q('#spin').hidden = true;
      q('#err').hidden = false;
      q('#err').textContent = 'Extension vừa được cập nhật — hãy tải lại trang này.';
    }
  }
  function fillLookup() {
    const d = S.lookup;
    if (!S.edited) q('#meaning').value = d.meaning || '';
    q('#meaning').placeholder = 'Nhập nghĩa…';
    if (d.phonetic && S.type !== 'sentence') q('#ph').textContent = d.phonetic;

    const pb = q('#posBox');
    pb.innerHTML = '';
    (d.meanings || []).slice(0, 4).forEach(m => {
      const row = document.createElement('div');
      row.className = 'mrow';
      const tag = document.createElement('span');
      tag.className = 'tag';
      tag.textContent = m.posVi || m.pos;
      row.appendChild(tag);
      row.appendChild(document.createTextNode((m.vi || []).slice(0, 4).join(', ')));
      if (m.def) {
        const df = document.createElement('div');
        df.className = 'def';
        df.textContent = m.def;
        row.appendChild(df);
      }
      pb.appendChild(row);
    });

    const eb = q('#exBox');
    eb.innerHTML = '';
    (d.examples || []).slice(0, 2).forEach(ex => {
      const row = document.createElement('div');
      row.className = 'exrow';
      const en = document.createElement('div');
      en.innerHTML = VS.markHTML(ex.en, [S.text]);
      row.appendChild(en);
      if (ex.vi) {
        const vi = document.createElement('div');
        vi.className = 'vi';
        vi.textContent = ex.vi;
        row.appendChild(vi);
      }
      eb.appendChild(row);
    });
    place();
  }

  /* ---------- Lưu ---------- */
  async function save() {
    const btn = q('#save');
    btn.disabled = true;
    try {
      const d = S.lookup || {};
      const payload = {
        type: S.type, text: S.text, meaning: q('#meaning').value.trim(),
        categoryId: q('#cat').value, enriched: !!S.lookup,
        source: { url: location.href, title: (document.title || '').slice(0, 200) }
      };
      if (S.type === 'sentence') {
        payload.focus = focusTerms();
      } else {
        Object.assign(payload, {
          phonetic: d.phonetic || '', audio: d.audio || '', pos: d.pos || [],
          meanings: d.meanings || [], defs: d.defs || [], examples: d.examples || []
        });
        if (S.context && q('#ctxChk').checked) payload.context = S.context;
      }
      const r = await VS.saveItem(payload);
      await VS.setSettings({ lastCategoryId: payload.categoryId });
      try {
        chrome.runtime.sendMessage({
          type: 'track',
          event: 'vocab_save',
          params: { item_type: S.type }
        });
      } catch (e) { /* bỏ qua */ }
      if (!r.item.enriched || !r.item.meaning) {
        try { chrome.runtime.sendMessage({ type: 'enrich', id: r.item.id }, () => void chrome.runtime.lastError); } catch (e) { /* bỏ qua */ }
      }
      q('#toast').textContent = r.updated ? '✓ Đã cập nhật' : '✓ Đã lưu';
      setTimeout(closePanel, 900);
    } catch (e) {
      btn.disabled = false;
      q('#toast').style.color = '#dc2626';
      q('#toast').textContent = 'Lỗi: tải lại trang rồi thử lại';
    }
  }

  /* ---------- Lệnh từ menu chuột phải / phím tắt ---------- */
  try {
    chrome.runtime.onMessage.addListener(msg => {
      if (!msg || msg.type !== 'openPanel') return;
      const sel = window.getSelection();
      if (sel && !sel.isCollapsed && sel.rangeCount) {
        const range = sel.getRangeAt(0).cloneRange();
        const text = sel.toString().replace(/\s+/g, ' ').trim();
        if (text && text.length <= MAX_LEN) openPanel(text, range, rectOf(range, null));
      } else if (msg.text && window === window.top) {
        const text = msg.text.replace(/\s+/g, ' ').trim();
        if (text && text.length <= MAX_LEN) openPanel(text, null, null);
      }
    });
  } catch (e) { /* bỏ qua */ }
})();
