/* Engclo – service worker: dịch, tra từ điển, lấy ví dụ, menu chuột phải, phím tắt */
importScripts('lib.js', 'analytics.js');

const FETCH_TIMEOUT = 9000;

async function fetchJSON(url) {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), FETCH_TIMEOUT);
  try {
    const r = await fetch(url, { signal: ctrl.signal });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    return await r.json();
  } finally { clearTimeout(t); }
}

/* ---------- Dịch ---------- */
async function googleTranslate(text, tl) {
  const url = 'https://translate.googleapis.com/translate_a/single?client=gtx&sl=en&tl=' +
    encodeURIComponent(tl) + '&dt=t&dt=bd&q=' + encodeURIComponent(text);
  const d = await fetchJSON(url);
  const translation = (d[0] || []).map(s => s && s[0]).filter(Boolean).join('').trim();
  const alts = (d[1] || []).map(e => ({ pos: String(e[0] || ''), words: (e[1] || []).slice(0, 5) }));
  return { translation, alts };
}
async function myMemory(text, tl) {
  const d = await fetchJSON('https://api.mymemory.translated.net/get?q=' +
    encodeURIComponent(text.slice(0, 480)) + '&langpair=en|' + encodeURIComponent(tl));
  const t = d && d.responseData && d.responseData.translatedText;
  if (!t) throw new Error('no translation');
  return { translation: t, alts: [] };
}
async function translate(text, tl) {
  try {
    const r = await googleTranslate(text, tl);
    if (r.translation) return r;
  } catch (e) { /* thử nguồn dự phòng */ }
  return myMemory(text, tl);
}

/* ---------- Từ điển (phiên âm, từ loại, định nghĩa, ví dụ) ---------- */
function candidates(w) {
  const s = [w];
  const add = x => { if (x && x.length > 2 && !s.includes(x)) s.push(x); };
  if (w.endsWith('ies')) add(w.slice(0, -3) + 'y');
  if (w.endsWith('ied')) add(w.slice(0, -3) + 'y');
  if (w.endsWith('es')) add(w.slice(0, -2));
  if (w.endsWith('s')) add(w.slice(0, -1));
  if (w.endsWith('ed')) { add(w.slice(0, -2)); add(w.slice(0, -1)); if (/([a-z])\1ed$/.test(w)) add(w.slice(0, -3)); }
  if (w.endsWith('ing')) {
    const b = w.slice(0, -3);
    add(b); add(b + 'e');
    if (/([a-z])\1$/.test(b)) add(b.slice(0, -1));
  }
  if (w.endsWith('ly')) add(w.slice(0, -2));
  return s.slice(0, 5);
}
async function dictionary(word) {
  for (const c of candidates(word)) {
    try {
      const d = await fetchJSON('https://api.dictionaryapi.dev/api/v2/entries/en/' + encodeURIComponent(c));
      if (Array.isArray(d) && d.length) return d;
    } catch (e) { /* thử dạng gốc tiếp theo */ }
  }
  return null;
}
function parseDict(entries) {
  let phonetic = '', audio = '';
  const defs = [], examples = [], seen = new Set();
  for (const e of entries) {
    if (!phonetic) phonetic = e.phonetic || (e.phonetics || []).map(p => p.text).find(Boolean) || '';
    if (!audio) audio = (e.phonetics || []).map(p => p.audio).find(Boolean) || '';
    for (const m of e.meanings || []) {
      const ds = m.definitions || [];
      if (ds[0] && !seen.has(m.partOfSpeech)) { seen.add(m.partOfSpeech); defs.push({ pos: m.partOfSpeech, def: ds[0].definition }); }
      for (const d of ds) if (d.example && examples.length < 6 && !examples.includes(d.example)) examples.push(d.example);
    }
  }
  return { phonetic, audio, defs, examples };
}
// Ví dụ dự phòng từ Tatoeba khi từ điển không có ví dụ
async function tatoeba(word) {
  try {
    const d = await fetchJSON('https://tatoeba.org/en/api_v0/search?from=eng&to=vie&orphans=no&unapproved=no&sort=relevance&query=' + encodeURIComponent(word));
    const re = new RegExp('(?<![A-Za-z])' + VS.escRe(word) + '(?![A-Za-z])', 'i');
    return (d.results || []).map(r => r.text).filter(t => t && re.test(t) && t.length >= 15 && t.length <= 140).slice(0, 3);
  } catch (e) { return []; }
}

/* ---------- Gộp dữ liệu cho một từ/cụm/câu ---------- */
async function lookup(text, type, tl) {
  text = String(text || '').trim();
  tl = tl || 'vi';
  const isWord = type === 'word' && !/\s/.test(text);
  const out = { text, type, meaning: '', meanings: [], pos: [], defs: [], phonetic: '', audio: '', examples: [] };

  if (!isWord) {
    const tr = await translate(text, tl);
    out.meaning = tr.translation;
    return out;
  }

  const [tr, dict] = await Promise.all([
    translate(text, tl).catch(() => null),
    dictionary(text.toLowerCase()).catch(() => null)
  ]);
  const d = dict ? parseDict(dict) : { phonetic: '', audio: '', defs: [], examples: [] };
  out.phonetic = d.phonetic; out.audio = d.audio; out.defs = d.defs;

  const defByPos = {};
  d.defs.forEach(x => { defByPos[x.pos] = x.def; });
  const alts = (tr && tr.alts) || [];
  alts.forEach(a => out.meanings.push({ pos: a.pos, posVi: VS.posVi(a.pos), vi: a.words, def: defByPos[a.pos] || '' }));
  d.defs.forEach(x => {
    if (!out.meanings.some(m => m.pos === x.pos)) out.meanings.push({ pos: x.pos, posVi: VS.posVi(x.pos), vi: [], def: x.def });
  });
  out.pos = [...new Set(out.meanings.map(m => m.posVi).filter(Boolean))];

  const first = [];
  if (tr && tr.translation) first.push(tr.translation);
  alts.forEach(a => { if (a.words[0]) first.push(a.words[0]); });
  const uniq = [];
  first.forEach(w => { if (!uniq.some(u => VS.norm(u) === VS.norm(w))) uniq.push(w); });
  out.meaning = uniq.slice(0, 4).join('; ');

  let ex = d.examples.slice(0, 3);
  if (ex.length < 2) {
    const more = await tatoeba(text);
    more.forEach(m => { if (ex.length < 3 && !ex.includes(m)) ex.push(m); });
  }
  out.examples = await Promise.all(ex.map(async en => {
    try { const t = await translate(en, tl); return { en, vi: t.translation }; }
    catch (e) { return { en, vi: '' }; }
  }));
  return out;
}

/* ---------- Bổ sung dữ liệu cho mục đã lưu ---------- */
async function enrich(id, force) {
  const it = await VS.getItem(id);
  if (!it) return null;
  const s = await VS.getSettings();
  const d = await lookup(it.text, it.type, s.targetLang);
  if (!d.meaning && !d.meanings.length) throw new Error('Không lấy được dữ liệu');
  return VS.updateItem(id, cur => {
    if (!cur.meaning && d.meaning) cur.meaning = d.meaning;
    const fill = (k, v) => {
      const empty = Array.isArray(cur[k]) ? !cur[k].length : !cur[k];
      if ((force || empty) && v && (!Array.isArray(v) || v.length)) cur[k] = v;
    };
    if (cur.type !== 'sentence') {
      fill('phonetic', d.phonetic); fill('audio', d.audio); fill('pos', d.pos);
      fill('meanings', d.meanings); fill('defs', d.defs); fill('examples', d.examples);
    }
    cur.enriched = true;
    return cur;
  });
}

/* ---------- Nhận tin nhắn ---------- */
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    try {
      switch (msg && msg.type) {
        case 'lookup': {
          const s = await VS.getSettings();
          sendResponse({ ok: true, data: await lookup(msg.text, msg.itemType, s.targetLang) });
          break;
        }
        case 'enrich':
          sendResponse({ ok: true, item: await enrich(msg.id, !!msg.force) });
          break;
        case 'openManage':
          await chrome.tabs.create({ url: chrome.runtime.getURL('manage.html' + (msg.hash ? '#' + msg.hash : '')) });
          sendResponse({ ok: true });
          break;
        case 'track':
          if (msg.event) {
            EngcloAnalytics.track(msg.event, msg.params);
          }
          sendResponse({ ok: true });
          break;
        case 'checkUpdate':
          sendResponse({ ok: true, data: await EngcloAnalytics.checkForUpdate() });
          break;
        default:
          sendResponse({ ok: false, error: 'unknown message' });
      }
    } catch (e) {
      sendResponse({ ok: false, error: String((e && e.message) || e) });
    }
  })();
  return true; // phản hồi bất đồng bộ
});

/* ---------- Menu chuột phải & phím tắt & Telemetry ---------- */
chrome.runtime.onInstalled.addListener(details => {
  VS.getCategories();
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({ id: 'vs-save', title: 'Lưu "%s" vào Engclo', contexts: ['selection'] });
  });

  // Thiết lập alarms: gửi heartbeat (mỗi 25 phút để luôn hiện Realtime GA4) và kiểm tra cập nhật (mỗi 4 giờ)
  chrome.alarms.create('engclo_heartbeat', { periodInMinutes: 25 });
  chrome.alarms.create('engclo_check_update', { delayInMinutes: 1, periodInMinutes: 240 });

  // Theo dõi lượt cài mới hoặc cập nhật
  if (details && details.reason === 'install') {
    EngcloAnalytics.track('app_install', {
      version: chrome.runtime.getManifest().version
    });
  } else if (details && details.reason === 'update') {
    EngcloAnalytics.track('app_update', {
      previous_version: details.previousVersion || '',
      version: chrome.runtime.getManifest().version
    });
  }

  // Ping khởi động & kiểm tra cập nhật lần đầu
  EngcloAnalytics.track('heartbeat', { online: 1 });
  EngcloAnalytics.checkForUpdate();
});

// Lắng nghe alarms định kỳ
chrome.alarms.onAlarm.addListener(alarm => {
  if (alarm.name === 'engclo_heartbeat') {
    EngcloAnalytics.track('heartbeat', { online: 1 });
  } else if (alarm.name === 'engclo_check_update') {
    EngcloAnalytics.checkForUpdate();
  }
});
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === 'vs-save' && tab && tab.id != null) {
    chrome.tabs.sendMessage(tab.id, { type: 'openPanel', text: info.selectionText || '' },
      info.frameId != null ? { frameId: info.frameId } : {}).catch(() => {});
  }
});
chrome.commands.onCommand.addListener(cmd => {
  if (cmd !== 'save-selection') return;
  chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
    if (tabs && tabs[0] && tabs[0].id != null) chrome.tabs.sendMessage(tabs[0].id, { type: 'openPanel' }).catch(() => {});
  });
});
